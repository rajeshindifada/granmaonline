import { LanguageConfig } from './types';

export const COLORS = {
  deepblack: '#0a0a0a',
  streetgreen: '#00c853',
  whitegrey: '#d3d3d3',
  radicalyellow: '#FFD400',
};

export const CATEGORIES = [
  'Politics',
  'Economics',
  'Caste',
  'World',
  'Indian News',
  'Peoples’ Struggles',
  'Culture',
  'Science & Knowledge',
  'International',
  'Sports',
  'Revolutionary Thought',
  'Radical Ecology',
  'Collective Intelligence'
];

export const LANGUAGES: LanguageConfig[] = [
  { code: 'en', name: 'English', native: 'English', dir: 'ltr', enabled: true },
  { code: 'es', name: 'Spanish', native: 'Español', dir: 'ltr', enabled: true },
  { code: 'fr', name: 'French', native: 'Français', dir: 'ltr', enabled: true },
  { code: 'zh', name: 'Mandarin Chinese', native: '普通话', dir: 'ltr', enabled: true },
  { code: 'ar', name: 'Arabic', native: 'العربية', dir: 'rtl', enabled: true },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം', dir: 'ltr', enabled: true },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்', dir: 'ltr', enabled: true },
  { code: 'el', name: 'Greek', native: 'Ελληνികാ', dir: 'ltr', enabled: true },
  { code: 'pt', name: 'Portuguese', native: 'Português', dir: 'ltr', enabled: true },
  { code: 'sw', name: 'Swahili', native: 'Kiswahili', dir: 'ltr', enabled: true },
  { code: 'qu', name: 'Quechua', native: 'Runa Simi', dir: 'ltr', enabled: true },
  { code: 'gn', name: 'Guarani', native: 'Avañeʼẽ', dir: 'ltr', enabled: true },
  { code: 'am', name: 'Amharic', native: 'አማርኛ', dir: 'ltr', enabled: true },
  { code: 'so', name: 'Somali', native: 'Soomaali', dir: 'ltr', enabled: true },
  { code: 'ha', name: 'Hausa', native: 'Hausa', dir: 'ltr', enabled: true },
  { code: 'yo', name: 'Yoruba', native: 'Yorùbá', dir: 'ltr', enabled: true },
];

export const AI_STYLES = [
  { name: 'Brutalist', desc: 'Raw, bold, high-contrast' },
  { name: 'Cyberpunk', desc: 'Neon, high-tech, dark' },
  { name: 'Minimalist', desc: 'Clean, simple, airy' },
  { name: 'Revolutionary Poster', desc: 'Constructivist, bold, red/black' },
  { name: 'Street Poetry', desc: 'Graffiti, raw, rhythmic' },
  { name: 'Academic Journal', desc: 'Formal, dense, structured' },
  { name: 'Retro Newspaper', desc: 'Grainy, sepia, classic' }
];

export const NAV_MENU = [
  { title: "Politics", type: "link", path: "/category/politics" },
  { title: "Economics", type: "link", path: "/category/economics" },
  { title: "Caste", type: "link", path: "/category/caste" },
  { title: "Revolutionary Thought", type: "link", path: "/category/Revolutionary Thought" },
  { title: "Radical Ecology", type: "link", path: "/category/Radical Ecology" },
  { title: "Collective Intelligence", type: "link", path: "/category/Collective Intelligence" },
  { title: "World", type: "dropdown", links: ["Asia", "Africa", "Europe", "North America", "Latin America", "Oceania"] },
  { title: "Indian News", type: "dropdown", links: ["National", "States", "Social Justice", "Peoples' Movements", "Economy", "Culture"] },
  { title: "Peoples’ Struggles", type: "dropdown", links: ["Dalit Liberation", "Adivasi Movements", "Kashmir", "Northeast Peoples", "Africa & Latin America"] },
  { title: "Culture", type: "dropdown", links: ["Visual Archive", "Literature", "Art", "Cinema", "Sports"] },
  { title: "Science & Knowledge", type: "dropdown", links: ["All Sciences", "Astronomy", "Political Economy", "Technology & AI"] },
  { title: "International", type: "dropdown", links: ["Asia", "Africa", "Latin America", "Europe", "Middle East"] },
  { title: "Sports", type: "link", path: "/category/sports" }
];
