import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, X, Search, Globe, Moon, Sun, Sparkles, 
  ArrowRight, Share2, Bookmark, MessageSquare,
  Image as ImageIcon, Video as VideoIcon, Mic,
  ChevronRight, ChevronLeft, Languages, Zap, Brain, Volume2,
  StopCircle, PlayCircle, Twitter, Facebook, Linkedin, Fingerprint, Key, Scan,
  Github, Rss, Pin, Asterisk, Home as HomeIcon
} from 'lucide-react';
import Markdown from 'react-markdown';
import { cn } from './lib/utils';
import { MOCK_ARTICLES, LANGUAGES, CATEGORIES } from './data/mock';
import { AI_STYLES, NAV_MENU } from './constants';
import { GoogleGenAI, Type } from "@google/genai";
import { geminiService } from './services/gemini';
import { dbService } from './services/db';
import { OptimizedImage } from './components/OptimizedImage';
import { useTranslation } from './translations';

// --- SEO Hook ---
const useSEO = ({ title, description, keywords, image }: { title?: string; description?: string; keywords?: string; image?: string }) => {
  useEffect(() => {
    const baseTitle = "granma: peoples international online collective";
    const fullTitle = title ? `${title} | ${baseTitle}` : baseTitle;
    const fullDesc = description || "An international online magazine for revolutionary thought, radical ecology, and collective intelligence.";
    const fullKeywords = keywords || "revolutionary, ecology, collective intelligence, international, magazine, AI, Gemini";
    const fullImage = image || "https://picsum.photos/seed/granma/1200/630";

    document.title = fullTitle;

    const setMeta = (name: string, content: string, isProperty = false) => {
      const attr = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attr}="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setMeta('description', fullDesc);
    setMeta('keywords', fullKeywords);
    
    // Open Graph
    setMeta('og:title', fullTitle, true);
    setMeta('og:description', fullDesc, true);
    setMeta('og:image', fullImage, true);
    setMeta('og:type', 'website', true);
    setMeta('og:url', window.location.href, true);

    // Twitter
    setMeta('twitter:card', 'summary_large_image');
    setMeta('twitter:title', fullTitle);
    setMeta('twitter:description', fullDesc);
    setMeta('twitter:image', fullImage);

  }, [title, description, keywords, image]);
};

// --- Components ---

const TopUtilityBar = ({ 
  theme, toggleTheme, currentLang, setLang, 
  isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery, searchRef, searchResults 
}: any) => {
  const { t } = useTranslation(currentLang.code);

  return (
    <div className="bg-black border-b border-white/10 h-10 flex items-center justify-between px-4 text-[10px] uppercase font-black tracking-widest text-white/40">
      <div className="flex items-center space-x-6">
        <Link to="/subscribe" className="hover:text-[#00c853] transition-colors">{t('subscribe')}</Link>
        <Link to="/donate" className="hover:text-[#00c853] transition-colors">{t('donate')}</Link>
        <Link to="/magazine" className="hover:text-[#00c853] transition-colors">{t('magazine')}</Link>
        <Link to="/catalyst" className="hover:text-[#00c853] transition-colors">{t('catalyst')}</Link>
      </div>
      
      <div className="flex items-center space-x-6">
        <Link to="/login" className="hover:text-[#00c853] transition-colors">{t('login')}</Link>
        
        {/* Search */}
        <div className="relative flex items-center" ref={searchRef}>
          <button 
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={cn("flex items-center space-x-2 hover:text-[#00c853] transition-colors", isSearchOpen && "text-[#00c853]")}
          >
            <Search size={12} />
            <span>{t('search')}</span>
          </button>
          
          <AnimatePresence>
            {isSearchOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute right-0 top-full mt-2 w-80 bg-[#111] border border-white/10 shadow-2xl overflow-hidden z-50 p-4"
              >
                <input 
                  autoFocus
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('search_placeholder')}
                  className="w-full bg-white/5 border border-white/10 px-4 py-2 text-[10px] focus:outline-none focus:border-[#00c853] text-white mb-4"
                />
                
                {searchQuery.trim() !== "" && (
                  <div className="space-y-4">
                    {searchResults.length > 0 ? (
                      searchResults.map((art: any) => (
                        <Link 
                          key={art.id}
                          to={`/article/${art.slug}`}
                          onClick={() => {
                            setIsSearchOpen(false);
                            setSearchQuery("");
                          }}
                          className="flex items-start space-x-3 group"
                        >
                          <div className="w-10 h-10 rounded overflow-hidden flex-shrink-0">
                            <img src={art.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-[8px] text-[#00c853] font-bold uppercase mb-1">{art.category}</div>
                            <h5 className="street-heading text-[10px] text-white/80 group-hover:text-white transition-colors line-clamp-2 leading-tight">{art.title}</h5>
                          </div>
                        </Link>
                      ))
                    ) : (
                      <div className="py-4 text-center">
                        <p className="text-[9px] text-white/20 italic">{t('no_results')}</p>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Language */}
        <div className="relative group">
          <button className="flex items-center space-x-1 hover:text-[#00c853] transition-colors">
            <Globe size={12} />
            <span>{currentLang.code}</span>
          </button>
          <div className="absolute right-0 top-full mt-2 w-48 bg-[#111] border border-white/10 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all p-2 grid grid-cols-2 gap-1 shadow-2xl z-50">
            {LANGUAGES.map(lang => (
              <button 
                key={lang.code}
                onClick={() => setLang(lang)}
                className={cn(
                  "text-[9px] p-2 rounded hover:bg-[#00c853] hover:text-black transition-colors text-left",
                  currentLang.code === lang.code && "bg-[#00c853]/20 text-[#00c853]"
                )}
              >
                {lang.native}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Navbar = ({ theme, toggleTheme, currentLang, setLang, logoUrl }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchRef = useRef<HTMLDivElement>(null);
  const { t } = useTranslation(currentLang.code);

  const searchResults = searchQuery.trim() === "" 
    ? [] 
    : MOCK_ARTICLES.filter(art => 
        art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        art.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        art.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      ).slice(0, 5);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getTranslatedTitle = (title: string) => {
    const key = title.toLowerCase().replace(/\s+/g, '_').replace('’', '');
    return t(key);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50">
      <TopUtilityBar 
        theme={theme} 
        toggleTheme={toggleTheme} 
        currentLang={currentLang} 
        setLang={setLang}
        isSearchOpen={isSearchOpen}
        setIsSearchOpen={setIsSearchOpen}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        searchRef={searchRef}
        searchResults={searchResults}
      />
      
      <div className="bg-[#0a0a0a] border-b border-white/10 py-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col items-center">
          <Link to="/" className="flex items-center space-x-6 group">
            {logoUrl && (
              <div className="w-16 h-16 md:w-24 md:h-24 rounded-full overflow-hidden border-2 border-white/10 group-hover:border-[#00c853] transition-all shadow-2xl">
                <img src={logoUrl} alt="granma logo" className="w-full h-full object-cover" />
              </div>
            )}
            <span className="mag-title text-7xl md:text-9xl font-black text-white group-hover:text-[#00c853] transition-colors tracking-tighter">
              granma
            </span>
          </Link>
        </div>
      </div>

      <nav 
        className="bg-[#0a0a0a]/90 backdrop-blur-xl border-b border-white/10"
        onMouseLeave={() => setActiveMenu(null)}
      >
        <div className="max-w-7xl mx-auto px-4 h-12 flex items-center justify-center">
          <div className="hidden lg:flex items-center space-x-8">
            {NAV_MENU.map(item => (
              <div 
                key={item.title} 
                className="relative h-12 flex items-center"
                onMouseEnter={() => item.type === 'dropdown' ? setActiveMenu(item.title) : setActiveMenu(null)}
              >
                {item.type === 'link' ? (
                  <Link 
                    to={item.path!} 
                    className="street-heading text-[10px] tracking-widest hover:text-[#00c853] transition-colors uppercase font-bold"
                  >
                    {getTranslatedTitle(item.title)}
                  </Link>
                ) : (
                  <button className={cn(
                    "street-heading text-[10px] tracking-widest hover:text-[#00c853] transition-colors uppercase font-bold flex items-center space-x-1",
                    activeMenu === item.title && "text-[#00c853]"
                  )}>
                    <span>{getTranslatedTitle(item.title)}</span>
                    <ChevronRight size={10} className="rotate-90" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="flex items-center space-x-4 ml-auto lg:ml-8">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full hover:bg-white/5 transition-colors text-white/40 hover:text-[#00c853]"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            
            <button onClick={() => setIsOpen(!isOpen)} className="lg:hidden p-2">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Dropdown Menu Overlay */}
        <AnimatePresence>
          {activeMenu && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute top-full left-0 w-full bg-[#0f0f0f] border-b border-white/10 shadow-2xl overflow-hidden"
            >
              <div className="max-w-7xl mx-auto px-4 py-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {NAV_MENU.find(m => m.title === activeMenu)?.links?.map((link: string) => (
                    <Link 
                      key={link} 
                      to={link === "Visual Archive" ? "/gallery" : `/category/${link.toLowerCase().replace(/\s+/g, '-')}`}
                      className="street-heading text-xs text-white/60 hover:text-[#00c853] transition-colors py-2 border-b border-white/5"
                      onClick={() => setActiveMenu(null)}
                    >
                      {link}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden absolute top-full left-0 w-full bg-[#0a0a0a] border-b border-white/10 overflow-y-auto max-h-[calc(100vh-8rem)]"
            >
              <div className="p-4 space-y-4">
                {NAV_MENU.map(item => (
                  <div key={item.title}>
                    {item.type === 'link' ? (
                      <Link 
                        to={item.path!} 
                        onClick={() => setIsOpen(false)}
                        className="street-heading text-sm text-white hover:text-[#00c853] block py-2"
                      >
                        {getTranslatedTitle(item.title)}
                      </Link>
                    ) : (
                      <div className="space-y-2">
                        <div className="street-heading text-[10px] text-white/20 uppercase tracking-widest">{getTranslatedTitle(item.title)}</div>
                        <div className="grid grid-cols-2 gap-2 pl-2">
                          {item.links?.map((link: string) => (
                            <Link 
                              key={link} 
                              to={link === "Visual Archive" ? "/gallery" : `/category/${link.toLowerCase().replace(/\s+/g, '-')}`} 
                              onClick={() => setIsOpen(false)}
                              className="text-xs text-white/60 py-1"
                            >
                              {link}
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
};

const CircularMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  const menuItems = [
    { icon: <HomeIcon size={20} />, label: 'Home', href: '/' },
    { icon: <Facebook size={20} />, label: 'Facebook', href: '#' },
    { icon: <Twitter size={20} />, label: 'Twitter', href: '#' },
    { icon: <Linkedin size={20} />, label: 'LinkedIn', href: '#' },
    { icon: <Github size={20} />, label: 'GitHub', href: '#' },
    { icon: <Rss size={20} />, label: 'RSS', href: '#' },
    { icon: <Pin size={20} />, label: 'Pinterest', href: '#' },
    { icon: <Asterisk size={20} />, label: 'Asterisk', href: '#' },
  ];

  return (
    <div className="relative flex items-center justify-center w-64 h-64 mx-auto mt-12">
      <AnimatePresence>
        {isOpen && (
          <div className="absolute inset-0 flex items-center justify-center">
            {menuItems.map((item, index) => {
              const angle = (index * 45) * (Math.PI / 180);
              const radius = 100;
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;

              return (
                <motion.a
                  key={index}
                  href={item.href}
                  initial={{ opacity: 0, x: 0, y: 0, scale: 0 }}
                  animate={{ opacity: 1, x, y, scale: 1 }}
                  exit={{ opacity: 0, x: 0, y: 0, scale: 0 }}
                  transition={{ 
                    type: "spring", 
                    stiffness: 260, 
                    damping: 20,
                    delay: index * 0.05 
                  }}
                  className="absolute w-12 h-12 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] hover:bg-[#00c853]/5 transition-all shadow-xl group"
                  title={item.label}
                >
                  {item.icon}
                </motion.a>
              );
            })}
          </div>
        )}
      </AnimatePresence>
      
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "relative z-10 w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl border-2",
          isOpen 
            ? "bg-black border-[#00c853] text-[#00c853] rotate-90" 
            : "bg-[#00c853] border-[#00c853] text-black hover:scale-110"
        )}
      >
        {isOpen ? <X size={28} /> : <Menu size={28} />}
      </button>
    </div>
  );
};

const Footer = ({ currentLang, logoUrl }: { currentLang: any, logoUrl: string | null }) => {
  const { t } = useTranslation(currentLang.code);
  return (
    <footer className="bg-black border-t border-white/10 pt-24 pb-12 px-4 mt-20">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-24">
          {/* Brand & Mission */}
          <div className="lg:col-span-4 space-y-8">
            <Link to="/" className="flex items-center space-x-4 group">
              {logoUrl && (
                <div className="w-12 h-12 rounded-full overflow-hidden border border-white/10 group-hover:border-[#00c853] transition-all">
                  <img src={logoUrl} alt="granma logo" className="w-full h-full object-cover" />
                </div>
              )}
              <h2 className="mag-title text-6xl text-white tracking-tighter group-hover:text-[#00c853] transition-colors">granma</h2>
            </Link>
            <p className="text-sm text-white/40 leading-relaxed max-w-sm font-serif italic">
              {t('tagline')}
            </p>
            <div className="flex items-center space-x-6">
              <a href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] transition-all group">
                <Twitter size={18} className="group-hover:scale-110 transition-transform" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] transition-all group">
                <Facebook size={18} className="group-hover:scale-110 transition-transform" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] transition-all group">
                <Linkedin size={18} className="group-hover:scale-110 transition-transform" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] transition-all group">
                <MessageSquare size={18} className="group-hover:scale-110 transition-transform" />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="lg:col-span-5 grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h3 className="street-heading text-[10px] mb-8 text-white/20 uppercase tracking-[0.3em] font-black">{t('sections')}</h3>
              <ul className="space-y-4 text-[10px] uppercase font-black tracking-widest">
                {CATEGORIES.slice(0, 6).map(cat => (
                  <li key={cat}>
                    <Link to={`/category/${cat}`} className="text-white/40 hover:text-[#00c853] transition-colors">{cat}</Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="street-heading text-[10px] mb-8 text-white/20 uppercase tracking-[0.3em] font-black">{t('about')}</h3>
              <ul className="space-y-4 text-[10px] uppercase font-black tracking-widest">
                <li><Link to="/about" className="text-white/40 hover:text-[#00c853] transition-colors">{t('about_us')}</Link></li>
                <li><Link to="/contact" className="text-white/40 hover:text-[#00c853] transition-colors">{t('contact')}</Link></li>
                <li><Link to="/advertise" className="text-white/40 hover:text-[#00c853] transition-colors">{t('advertise')}</Link></li>
                <li><Link to="/privacy" className="text-white/40 hover:text-[#00c853] transition-colors">{t('privacy_policy')}</Link></li>
                <li><Link to="/store" className="text-white/40 hover:text-[#00c853] transition-colors">{t('store')}</Link></li>
              </ul>
            </div>
            <div className="hidden md:block">
              <h3 className="street-heading text-[10px] mb-8 text-white/20 uppercase tracking-[0.3em] font-black">{t('catalyst')}</h3>
              <ul className="space-y-4 text-[10px] uppercase font-black tracking-widest">
                <li><a href="https://catalyst-journal.com" target="_blank" rel="noopener noreferrer" className="text-white/40 hover:text-[#00c853] transition-colors">Catalyst Journal</a></li>
                <li><a href="#" className="text-white/40 hover:text-[#00c853] transition-colors">Current Issue</a></li>
                <li><a href="#" className="text-white/40 hover:text-[#00c853] transition-colors">Archive</a></li>
                <li><a href="#" className="text-white/40 hover:text-[#00c853] transition-colors">{t('subscribe')}</a></li>
              </ul>
            </div>
          </div>

          {/* Newsletter / Support */}
          <div className="lg:col-span-3">
            <div className="bg-zinc-900/50 p-8 border border-white/5 relative group">
              <div className="absolute top-0 left-0 w-full h-[1px] bg-[#00c853] scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
              <h3 className="street-heading text-xs mb-4 text-white uppercase tracking-[0.2em] font-black">{t('support_the_struggle')}</h3>
              <p className="text-[10px] text-white/40 mb-8 leading-relaxed uppercase tracking-widest font-bold">
                {t('independent_journalism_support')}
              </p>
              <Link to="/subscribe" className="block w-full bg-[#00c853] text-black py-4 text-[10px] font-black uppercase text-center hover:bg-white transition-all duration-300 tracking-[0.2em]">
                {t('subscribe_now')}
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
            <span className="text-[10px] uppercase font-black tracking-widest text-white/20">
              © 2026 granma collective
            </span>
            <div className="flex items-center space-x-6">
              <span className="text-[10px] uppercase font-black tracking-widest text-white/10 hover:text-[#00c853] cursor-default transition-colors">
                {t('decentralize_everything')}
              </span>
              <span className="text-[10px] uppercase font-black tracking-widest text-white/10 hover:text-[#00c853] cursor-default transition-colors">
                {t('power_to_the_people')}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-6">
            <CircularMenu />
            <h1 className="text-[10px] uppercase font-black tracking-[0.4em] text-white/10">
              Demo by <a href="http://creative-punch.net" target="_blank" rel="noopener noreferrer" className="hover:text-[#00c853] transition-colors">Creative Punch</a>
            </h1>
          </div>

          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-[#00c853] rounded-full animate-pulse"></div>
              <span className="text-[10px] uppercase font-black tracking-widest text-white/40">Network Status: Active</span>
            </div>
            <button 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="text-[10px] uppercase font-black tracking-widest text-white/20 hover:text-white transition-colors flex items-center space-x-2 group"
            >
              <span>Back to Top</span>
              <ChevronRight size={14} className="-rotate-90 group-hover:-translate-y-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Pages ---

const ArticleCard = ({ article, variant = 'default', currentLang }: { article: any, variant?: 'default' | 'insight' | 'trending' | 'minimal' | 'related', currentLang: any }) => {
  const { t } = useTranslation(currentLang.code);
  
  if (variant === 'insight') {
    return (
      <Link to={`/article/${article.slug}`} className="group block bg-white/5 p-8 border border-white/5 hover:border-[#00c853]/30 transition-all h-full flex flex-col">
        <div className="text-[10px] uppercase font-black text-[#00c853] tracking-widest mb-6">Insight</div>
        <h3 className="mag-title text-2xl mb-4 group-hover:text-[#00c853] transition-colors leading-tight">
          {article.title}
        </h3>
        <div className="overflow-hidden transition-all duration-500 max-h-0 group-hover:max-h-32 opacity-0 group-hover:opacity-100">
          <p className="text-sm text-white/40 leading-relaxed mb-6 line-clamp-3 font-serif italic">
            {article.excerpt || article.dek}
          </p>
        </div>
        <div className="mt-auto flex items-center justify-between pt-4 border-t border-white/5">
          <span className="text-[10px] uppercase font-bold text-white/20 tracking-widest">{article.author}</span>
          <ArrowRight size={16} className="text-[#00c853] transform group-hover:translate-x-2 transition-transform" />
        </div>
      </Link>
    );
  }

  if (variant === 'trending') {
    return (
      <Link to={`/article/${article.slug}`} className="flex-shrink-0 w-80 group block">
        <div className="aspect-[4/3] overflow-hidden mb-4 grayscale group-hover:grayscale-0 transition-all duration-500 relative">
          <img src={article.image} alt={article.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
            <p className="text-[10px] text-white font-bold uppercase tracking-widest leading-relaxed line-clamp-4">
              {article.excerpt || article.dek}
            </p>
          </div>
        </div>
        <h5 className="street-heading text-xs text-white/80 group-hover:text-[#00c853] transition-colors leading-snug line-clamp-2 uppercase font-bold tracking-tight">
          {article.title}
        </h5>
      </Link>
    );
  }

  if (variant === 'minimal') {
    return (
      <Link to={`/article/${article.slug}`} className="group block">
        <h5 className="street-heading text-sm text-white/90 group-hover:text-[#00c853] transition-colors leading-snug uppercase font-bold tracking-tight mb-2">
          {article.title}
        </h5>
        <div className="overflow-hidden transition-all duration-500 max-h-0 group-hover:max-h-20 opacity-0 group-hover:opacity-100">
          <p className="text-[9px] text-white/40 leading-relaxed mb-2 line-clamp-2 italic">
            {article.excerpt || article.dek}
          </p>
        </div>
        <p className="text-[10px] text-white/30 uppercase font-black tracking-widest">{article.publishedAt}</p>
      </Link>
    );
  }

  if (variant === 'related') {
    return (
      <Link to={`/article/${article.slug}`} className="group block relative">
        <div className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="bg-[#00c853] text-black text-[8px] font-black uppercase px-2 py-1 rounded-full flex items-center space-x-1 shadow-xl">
            <Sparkles size={10} />
            <span>AI Match</span>
          </div>
        </div>
        <div className="aspect-video overflow-hidden rounded-2xl mb-6 border border-white/5 group-hover:border-[#00c853]/30 transition-all relative">
          <img src={article.image} alt={article.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
            {article.recommendationReason && (
              <div className="mb-2">
                <span className="text-[8px] text-[#00c853] font-black uppercase tracking-widest bg-black/40 px-2 py-0.5 rounded">
                  {article.recommendationReason}
                </span>
              </div>
            )}
            <p className="text-white text-[10px] font-serif italic line-clamp-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
              {article.excerpt || article.dek}
            </p>
          </div>
        </div>
        <h5 className="street-heading text-sm text-white/80 group-hover:text-[#00c853] transition-colors leading-snug uppercase font-bold tracking-tight">
          {article.title}
        </h5>
        <div className="mt-4 text-[8px] uppercase font-black text-white/20 tracking-widest">
          {article.categories?.[0] || article.category}
        </div>
      </Link>
    );
  }

  return (
    <Link to={`/article/${article.slug}`} className="group block">
      <div className="aspect-video overflow-hidden mb-8 relative">
        <img src={article.image} alt={article.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-8">
          <p className="text-white text-sm font-serif italic line-clamp-3 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
            {article.excerpt || article.dek}
          </p>
        </div>
      </div>
      <div className="flex items-center space-x-3 mb-4">
        <span className="text-[10px] uppercase font-black text-[#00c853] tracking-widest">
          {article.categories ? article.categories[0] : article.category}
        </span>
        <span className="w-1 h-1 bg-white/20 rounded-full"></span>
        <span className="text-[10px] uppercase font-bold text-white/40 tracking-widest">{article.publishedAt}</span>
      </div>
      <h2 className="mag-title text-4xl md:text-5xl mb-4 group-hover:text-[#00c853] transition-colors leading-tight">
        {article.title}
      </h2>
      <div className="text-[10px] uppercase font-black tracking-widest text-white/40">
        {t('by')} {article.author}
      </div>
    </Link>
  );
};

const Home = ({ currentLang }: { currentLang: any }) => {
  const { category: urlCategory } = useParams();
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState(urlCategory || 'all');
  const [currentPage, setCurrentPage] = useState(1);
  const [articles, setArticles] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const itemsPerPage = 10;
  const { t } = useTranslation(currentLang.code);

  useEffect(() => {
    const fetchArticles = async () => {
      setIsLoading(true);
      try {
        const data = await dbService.getArticles();
        setArticles(data);
      } catch (e) {
        console.error(e);
        setArticles(MOCK_ARTICLES); // Fallback
      } finally {
        setIsLoading(false);
      }
    };
    fetchArticles();
  }, []);

  useSEO({
    title: selectedCategory === 'all' ? "Home" : `Collective: ${selectedCategory}`,
    description: t('tagline'),
    keywords: "revolutionary thought, radical ecology, collective intelligence, international magazine"
  });

  useEffect(() => {
    if (urlCategory) {
      setSelectedCategory(urlCategory);
      setCurrentPage(1);
    }
  }, [urlCategory]);

  const allFilteredArticles = (selectedCategory === 'all' 
    ? articles 
    : articles.filter(a => 
        a.categories && Array.isArray(a.categories) 
          ? a.categories.includes(selectedCategory) 
          : a.category === selectedCategory
      ));

  const featured = allFilteredArticles[0];
  const featuredCols = allFilteredArticles.slice(1, 3);
  const insightCards = allFilteredArticles.slice(3, 6);
  const featuredDispatch = allFilteredArticles[6];
  const trending = allFilteredArticles.slice(7, 13);
  const opinionEssays = allFilteredArticles.slice(13, 18);

  if (isLoading) {
    return (
      <div className="pt-48 px-4 max-w-7xl mx-auto flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 border-4 border-[#00c853] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[10px] uppercase font-black tracking-[0.3em] text-white/40 animate-pulse">Initializing Collective Intelligence...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-48 px-4 max-w-7xl mx-auto">
      {/* 1. HERO FEATURE (Full Width - 12 col) */}
      {featured && (
        <section className="mb-20">
          <Link to={`/article/${featured.slug}`} className="group block relative overflow-hidden">
            <div className="relative aspect-[21/9] w-full overflow-hidden">
              <img 
                src={featured.image} 
                alt={featured.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 p-8 md:p-16 w-full">
                <div className="flex items-center space-x-4 mb-6">
                  <span className="bg-[#00c853] text-black px-3 py-1 text-[10px] font-black uppercase tracking-widest">
                    {featured.categories ? featured.categories[0] : featured.category}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-white tracking-widest">{featured.publishedAt}</span>
                </div>
                <h1 className="mag-title text-5xl md:text-9xl mb-6 group-hover:text-[#00c853] transition-colors leading-none tracking-tighter max-w-5xl">
                  {featured.title}
                </h1>
                <p className="text-xl text-white/80 max-w-3xl leading-relaxed line-clamp-2 font-serif italic">
                  {featured.dek}
                </p>
              </div>
            </div>
          </Link>
        </section>
      )}

      {/* 2. 2 Featured Columns (6 col / 6 col) */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20 border-b border-white/10 pb-20">
        {featuredCols.map((art) => (
          <ArticleCard key={art.id} article={art} currentLang={currentLang} />
        ))}
      </section>

      {/* 3. 3 Insight Cards (4 / 4 / 4) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        {insightCards.map((art) => (
          <ArticleCard key={art.id} article={art} variant="insight" currentLang={currentLang} />
        ))}
      </section>

      {/* 3.5 Single Featured Dispatch */}
      {featuredDispatch && (
        <section className="mb-20">
          <Link to={`/article/${featuredDispatch.slug}`} className="group block relative overflow-hidden bg-zinc-900 border border-white/5">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/2 aspect-video md:aspect-auto overflow-hidden">
                <img 
                  src={featuredDispatch.image} 
                  alt={featuredDispatch.title} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                />
              </div>
              <div className="md:w-1/2 p-12 flex flex-col justify-center">
                <div className="text-[10px] uppercase font-black text-[#00c853] tracking-[0.3em] mb-6">Featured Dispatch</div>
                <h2 className="mag-title text-4xl md:text-6xl mb-6 group-hover:text-[#00c853] transition-colors leading-tight">
                  {featuredDispatch.title}
                </h2>
                <p className="text-white/60 leading-relaxed mb-8 font-serif italic text-lg">
                  {featuredDispatch.dek}
                </p>
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-[#00c853] flex items-center justify-center text-black">
                    <ArrowRight size={20} />
                  </div>
                  <span className="text-[10px] uppercase font-black tracking-widest text-white/40">Read the Full Report</span>
                </div>
              </div>
            </div>
          </Link>
        </section>
      )}

      {/* 4. Trending Now Strip (Horizontal Scroll) */}
      <section className="mb-20 overflow-hidden">
        <div className="flex items-center justify-between mb-8 border-b border-white/10 pb-4">
          <h4 className="street-heading text-[10px] text-white/40 uppercase tracking-[0.3em] font-black">Trending Now</h4>
          <div className="flex space-x-2">
            <div className="w-2 h-2 rounded-full bg-[#00c853] animate-pulse"></div>
            <span className="text-[10px] text-[#00c853] font-bold uppercase tracking-widest">Live Feed</span>
          </div>
        </div>
        <div className="flex space-x-8 overflow-x-auto pb-8 scrollbar-hide">
          {trending.map((art) => (
            <ArticleCard key={art.id} article={art} variant="trending" currentLang={currentLang} />
          ))}
        </div>
      </section>

      {/* 5. Category Blocks (Politics | Economy | Culture) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-20">
        {['Politics', 'Economy', 'Culture'].map(cat => (
          <div key={cat} className="space-y-8">
            <div className="flex items-center justify-between border-b-2 border-white pb-4">
              <h4 className="mag-title text-3xl uppercase tracking-tighter">{cat}</h4>
              <Link to={`/category/${cat.toLowerCase()}`} className="text-[10px] font-black uppercase text-[#00c853] hover:underline tracking-widest">View All</Link>
            </div>
            <div className="space-y-8">
              {articles.filter(a => a.category === cat.toLowerCase()).slice(0, 3).map(art => (
                <ArticleCard key={art.id} article={art} variant="minimal" currentLang={currentLang} />
              ))}
            </div>
          </div>
        ))}
      </section>

      {/* 6. Opinion / Essays (Stack Layout) */}
      <section className="mb-20 bg-zinc-900/30 p-12 border border-white/5">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h4 className="mag-title text-5xl mb-4">Opinion & Essays</h4>
            <p className="text-[10px] text-white/30 uppercase tracking-[0.4em] font-black">Radical Perspectives on the Global Order</p>
          </div>
          <div className="space-y-12">
            {opinionEssays.map((art) => (
              <Link key={art.id} to={`/article/${art.slug}`} className="group flex flex-col md:flex-row items-center gap-8 border-b border-white/5 pb-12 last:border-0">
                <div className="w-24 h-24 rounded-full overflow-hidden grayscale group-hover:grayscale-0 transition-all flex-shrink-0 border-2 border-white/10 group-hover:border-[#00c853]">
                  <img src={art.image} alt={art.author} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h5 className="mag-title text-3xl mb-2 group-hover:text-[#00c853] transition-colors leading-tight">
                    {art.title}
                  </h5>
                  <div className="flex items-center justify-center md:justify-start space-x-3">
                    <span className="text-[10px] uppercase font-black text-[#00c853] tracking-widest">{art.author}</span>
                    <span className="w-1 h-1 bg-white/10 rounded-full"></span>
                    <span className="text-[10px] uppercase font-bold text-white/20 tracking-widest">{art.publishedAt}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* 7. More Category Blocks (World | International | Peoples’ Struggles) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-20">
        {['World', 'International', 'Peoples’ Struggles'].map(cat => (
          <div key={cat} className="space-y-8">
            <div className="flex items-center justify-between border-b-2 border-white pb-4">
              <h4 className="mag-title text-3xl uppercase tracking-tighter">{cat}</h4>
              <Link to={`/category/${cat.toLowerCase()}`} className="text-[10px] font-black uppercase text-[#00c853] hover:underline tracking-widest">View All</Link>
            </div>
            <div className="space-y-8">
              {articles.filter(a => a.category === cat || a.category === cat.toLowerCase()).slice(0, 3).map(art => (
                <ArticleCard key={art.id} article={art} variant="minimal" currentLang={currentLang} />
              ))}
            </div>
          </div>
        ))}
      </section>

      {/* PROMOTIONAL STRIP */}
      <section className="bg-[#00c853] text-black py-12 px-8 mb-16 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="text-center md:text-left">
          <h2 className="mag-title text-3xl md:text-4xl mb-2">Support granma</h2>
          <p className="street-heading text-[10px] uppercase font-black tracking-widest opacity-60">An international online collective for independent left journalism</p>
        </div>
        <Link to="/subscribe" className="bg-black text-white px-10 py-4 text-xs font-black uppercase hover:bg-zinc-800 transition-colors">
          {t('subscribe')}
        </Link>
      </section>
    </div>
  );
};

const ArticlePage = ({ currentLang: globalLang }: { currentLang: any }) => {
  const { slug } = useParams();
  const [article, setArticle] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { t } = useTranslation(globalLang.code);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [translatedContent, setTranslatedContent] = useState<string | null>(null);
  const [translatedTitle, setTranslatedTitle] = useState<string | null>(null);
  const [translatedDek, setTranslatedDek] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [targetLang, setTargetLang] = useState(globalLang);
  const [relatedArticles, setRelatedArticles] = useState<any[]>([]);
  const [isLoadingRelated, setIsLoadingRelated] = useState(false);
  const [nextArticle, setNextArticle] = useState<any>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isShareDropdownOpen, setIsShareDropdownOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const relatedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchArticle = async () => {
      setIsLoading(true);
      try {
        if (slug) {
          const data = await dbService.getArticleBySlug(slug);
          setArticle(data);
        }
      } catch (e) {
        console.error(e);
        setArticle(MOCK_ARTICLES[0]); // Fallback
      } finally {
        setIsLoading(false);
      }
    };
    fetchArticle();
  }, [slug]);

  useEffect(() => {
    if (!article) return;
    const fetchSummary = async () => {
      setIsSummarizing(true);
      try {
        const result = await geminiService.generateSummary(article.content);
        setSummary(result);
      } catch (e) {
        console.error("Summary failed:", e);
      } finally {
        setIsSummarizing(false);
      }
    };
    fetchSummary();
  }, [article?.id]);

  useEffect(() => {
    setTargetLang(globalLang);
    // Auto-translate if not English and article is loaded
    if (article && globalLang.code !== 'en') {
      handleTranslate(globalLang.code);
    } else {
      setTranslatedContent(null);
      setTranslatedTitle(null);
      setTranslatedDek(null);
    }
  }, [globalLang, article?.id]);

  useEffect(() => {
    if (!article) return;
    const fetchRelated = async () => {
      setIsLoadingRelated(true);
      try {
        const allArticles = await dbService.getArticles();
        
        // Find next article in the sequence
        const currentIndex = allArticles.findIndex((a: any) => a.id === article.id);
        if (currentIndex !== -1 && currentIndex < allArticles.length - 1) {
          setNextArticle(allArticles[currentIndex + 1]);
        } else {
          setNextArticle(null);
        }

        const suggested = await geminiService.getRelatedArticles(article, allArticles);
        setRelatedArticles(suggested);
      } catch (e) {
        console.error(e);
        setRelatedArticles(MOCK_ARTICLES
          .filter(a => a.id !== article.id && (
            (a.categories?.includes(article.categories?.[0] || article.category)) || 
            (a.category === article.category) || 
            a.tags.some(t => article.tags.includes(t))
          ))
          .slice(0, 6));
      } finally {
        setIsLoadingRelated(false);
      }
    };
    fetchRelated();
  }, [article]);

  const handleAnalyze = async () => {
    if (!article || isAnalyzing) return;
    setIsAnalyzing(true);
    try {
      const result = await geminiService.analyzeArticle(article.content);
      setAnalysis(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleTranslate = async (code?: string, name?: string) => {
    if (!article || isTranslating) return;
    const langCode = code || targetLang.code;
    const langName = name || targetLang.name;

    if (langCode === 'en') {
      setTranslatedContent(null);
      setTranslatedTitle(null);
      setTranslatedDek(null);
      return;
    }

    // 1. Check if translation exists in the database
    const existing = article.translations?.find((t: any) => t.lang_code === langCode);
    if (existing) {
      setTranslatedTitle(existing.title);
      setTranslatedDek(existing.dek);
      setTranslatedContent(existing.content);
      return;
    }

    setIsTranslating(true);
    try {
      // 2. Translate using geminiService
      const result = await geminiService.translate(
        { title: article.title, dek: article.dek, content: article.content },
        langName
      );
      
      setTranslatedTitle(result.title);
      setTranslatedDek(result.dek);
      setTranslatedContent(result.content);

      // 3. Save to database for future users
      await dbService.saveTranslation(article.id, langCode, result);
      
      // Update local article state to include the new translation
      setArticle((prev: any) => ({
        ...prev,
        translations: [...(prev.translations || []), { lang_code: langCode, ...result }]
      }));

    } catch (e) {
      console.error("Translation failed:", e);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!article) return;
    setIsGeneratingImage(true);
    try {
      // 1. Generate a prompt for the image
      const promptResult = await geminiService.fastResponse(`Create a highly detailed, documentary-style photography prompt for an article titled "${article.title}". 
      The article is about: ${article.dek}. 
      Keywords: ${article.tags?.join(', ')}.
      The style should be: high contrast, cinematic, socio-political, authentic.
      Return ONLY the prompt text, no extra commentary.`);
      
      const imagePrompt = promptResult || `A powerful socio-political documentary photograph representing ${article.title}`;
      
      // 2. Generate the image using Flash (no user key needed)
      const imageUrl = await geminiService.generateImage(imagePrompt, "16:9");
      
      if (imageUrl) {
        // 3. Save to database
        await dbService.updateArticleImage(article.id, imageUrl, imagePrompt);
        
        // 4. Update local state
        setArticle((prev: any) => ({
          ...prev,
          image: imageUrl,
          image_prompt: imagePrompt
        }));
      }
    } catch (e) {
      console.error("Image generation failed:", e);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleShare = (platform?: string) => {
    const url = window.location.href;
    const title = article?.title || "Antigravity Dispatch";
    
    if (!platform) {
      if (navigator.share) {
        navigator.share({ title, url }).catch(console.error);
      } else {
        navigator.clipboard.writeText(url);
        alert("Link copied to clipboard");
      }
      return;
    }

    const shareUrls: Record<string, string> = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
    };

    window.open(shareUrls[platform], '_blank');
  };

  if (isLoading || !article) {
    return (
      <div className="pt-48 px-4 max-w-7xl auto flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 border-4 border-[#00c853] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[10px] uppercase font-black tracking-[0.3em] text-white/40 animate-pulse">Accessing Collective Archives...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-32 px-6 max-w-5xl mx-auto relative">
      {/* Background Decorative Element */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-gradient-to-b from-[#00c853]/5 to-transparent -z-10 blur-3xl rounded-full"></div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="text-center mb-12">
          <div className="flex flex-wrap justify-center gap-4 mb-4">
            {(article.categories || [article.category]).map((cat: string) => (
              <Link key={cat} to={`/category/${cat}`} className="text-[#00c853] uppercase font-bold text-xs tracking-widest hover:underline">
                {cat}
              </Link>
            ))}
          </div>
          <h1 className="mag-title text-5xl md:text-8xl mb-8 leading-[0.95] tracking-tighter">
            {translatedTitle || article.title}
          </h1>
          <p className="text-xl md:text-2xl text-white/50 font-serif italic max-w-3xl mx-auto leading-relaxed">
            {translatedDek || article.dek}
          </p>
          <div className="mt-8 flex items-center justify-center space-x-6 text-[10px] uppercase font-black text-white/30 tracking-[0.2em]">
            <span className="flex items-center space-x-2">
              <span className="w-1.5 h-1.5 bg-[#00c853] rounded-full"></span>
              <span>{t('by')} {article.author}</span>
            </span>
            <span>{article.publishedAt}</span>
            <span className="flex items-center space-x-2">
              <Volume2 size={12} className="text-[#00c853]" />
              <span>{Math.ceil(article.content.split(' ').length / 200)} {t('min_read')}</span>
            </span>
          </div>
        </div>

        <OptimizedImage 
          src={article.image} 
          alt={article.title} 
          aspectRatio="video"
          variant="bold"
          containerClassName="mb-16"
          className="group-hover:scale-105 transition-transform duration-[400ms]"
          overlay={
            <div className="absolute inset-0 p-8 flex flex-col justify-between pointer-events-none">
              <div className="flex justify-end">
                {article.image_prompt && (
                  <span className="bg-black/80 backdrop-blur-md text-[#00c853] border border-[#00c853]/30 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-[0.2em] flex items-center space-x-2 shadow-2xl">
                    <Zap size={10} className="animate-pulse" />
                    <span>Neural Generation</span>
                  </span>
                )}
              </div>
              <div className="bg-gradient-to-t from-black/60 to-transparent -mx-8 -mb-8 p-8">
                <span className="inline-block bg-[#00c853] text-black px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl">
                  {article.categories?.[0] || article.category}
                </span>
              </div>
            </div>
          }
        />

        <div className="flex flex-wrap items-center justify-between mb-12 gap-6 border-b border-white/10 pb-8">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex flex-col space-y-2">
              <span className="text-[10px] uppercase font-black text-white/20 tracking-[0.2em] ml-2">Content Language</span>
              <div className="relative group">
                <div className="flex items-center bg-white/5 border border-white/10 rounded-full p-1.5 backdrop-blur-sm">
                  <div className="flex items-center space-x-1 px-3 py-1.5">
                    <Sparkles size={14} className="text-[#00c853] animate-pulse" />
                    <span className="text-[10px] font-black uppercase text-[#00c853] tracking-widest">Neural Translate</span>
                  </div>
                  <div className="h-4 w-px bg-white/10 mx-2" />
                  <div className="flex items-center space-x-1">
                    {LANGUAGES.slice(0, 4).map(l => (
                      <button
                        key={l.code}
                        onClick={() => {
                          setTargetLang(l);
                          handleTranslate(l.code, l.name);
                        }}
                        className={cn(
                          "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all",
                          targetLang.code === l.code 
                            ? "bg-[#00c853] text-black shadow-[0_0_15px_rgba(0,200,83,0.3)]" 
                            : "text-white/40 hover:text-white hover:bg-white/5"
                        )}
                      >
                        {l.code}
                      </button>
                    ))}
                    <div className="relative">
                      <button 
                        onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                        className={cn(
                          "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all flex items-center space-x-1",
                          !LANGUAGES.slice(0, 4).find(l => l.code === targetLang.code) && targetLang.code !== 'en'
                            ? "bg-[#00c853] text-black"
                            : "text-white/40 hover:text-white hover:bg-white/5"
                        )}
                      >
                        <span>More</span>
                        <ChevronRight size={12} className={cn("transition-transform", isLangDropdownOpen ? "rotate-90" : "")} />
                      </button>
                      
                      <AnimatePresence>
                        {isLangDropdownOpen && (
                          <motion.div 
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            className="absolute top-full right-0 mt-4 w-56 bg-[#111] border border-white/10 rounded-2xl overflow-hidden z-50 shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-xl"
                          >
                            <div className="p-4 border-b border-white/5 bg-white/5">
                              <p className="text-[9px] uppercase font-black text-white/30 tracking-widest">All Languages</p>
                            </div>
                            <div className="max-h-64 overflow-y-auto scrollbar-hide">
                              {LANGUAGES.map(lang => (
                                <button
                                  key={lang.code}
                                  onClick={() => {
                                    setTargetLang(lang);
                                    handleTranslate(lang.code, lang.name);
                                    setIsLangDropdownOpen(false);
                                  }}
                                  className={cn(
                                    "w-full px-6 py-4 text-left text-[10px] uppercase font-black tracking-widest hover:bg-[#00c853] hover:text-black transition-colors flex items-center justify-between group/item",
                                    targetLang.code === lang.code ? "text-[#00c853]" : "text-white/60"
                                  )}
                                >
                                  <span>{lang.name}</span>
                                  {targetLang.code === lang.code && <div className="w-1.5 h-1.5 rounded-full bg-[#00c853] group-hover/item:bg-black" />}
                                </button>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col space-y-2">
              <span className="text-[10px] uppercase font-black text-white/20 tracking-[0.2em] ml-2">Intelligence</span>
              <button 
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="flex items-center space-x-3 bg-indigo-900/10 border border-indigo-500/20 px-6 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all group"
              >
                <Brain size={16} className="text-indigo-400 group-hover:text-white transition-colors" />
                <span>{isAnalyzing ? "Synthesizing..." : "Deep Analysis"}</span>
              </button>
            </div>
          </div>

          <div className="relative">
            <button 
              onClick={() => setIsShareDropdownOpen(!isShareDropdownOpen)}
              className="flex items-center space-x-2 bg-white/5 border border-white/10 px-6 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:border-[#00c853] transition-all"
            >
              <Share2 size={16} className="text-[#00c853]" />
              <span>Share to...</span>
              <ChevronRight size={14} className={cn("transition-transform", isShareDropdownOpen ? "rotate-90" : "")} />
            </button>
            
            <AnimatePresence>
              {isShareDropdownOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full right-0 mt-2 w-48 bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden z-50 shadow-2xl"
                >
                  <button
                    onClick={() => { handleShare('twitter'); setIsShareDropdownOpen(false); }}
                    className="w-full px-6 py-4 text-left text-[10px] uppercase font-black tracking-widest hover:bg-[#00c853] hover:text-black transition-colors flex items-center space-x-3"
                  >
                    <Twitter size={14} />
                    <span>Twitter</span>
                  </button>
                  <button
                    onClick={() => { handleShare('facebook'); setIsShareDropdownOpen(false); }}
                    className="w-full px-6 py-4 text-left text-[10px] uppercase font-black tracking-widest hover:bg-[#00c853] hover:text-black transition-colors flex items-center space-x-3"
                  >
                    <Facebook size={14} />
                    <span>Facebook</span>
                  </button>
                  <button
                    onClick={() => { handleShare('linkedin'); setIsShareDropdownOpen(false); }}
                    className="w-full px-6 py-4 text-left text-[10px] uppercase font-black tracking-widest hover:bg-[#00c853] hover:text-black transition-colors flex items-center space-x-3"
                  >
                    <Linkedin size={14} />
                    <span>LinkedIn</span>
                  </button>
                  <button
                    onClick={() => { handleShare(); setIsShareDropdownOpen(false); }}
                    className="w-full px-6 py-4 text-left text-[10px] uppercase font-black tracking-widest hover:bg-[#00c853] hover:text-black transition-colors flex items-center space-x-3 border-t border-white/5"
                  >
                    <Share2 size={14} />
                    <span>Copy Link</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="article-content drop-cap mb-12" ref={contentRef}>
          <Markdown>{translatedContent || article.content}</Markdown>
        </div>

        {/* Social Share Buttons */}
        <div className="flex flex-col items-center space-y-6 mb-20 border-t border-white/5 pt-12">
          <span className="text-[10px] uppercase font-black text-white/20 tracking-[0.4em]">Spread the Dispatch</span>
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => handleShare('twitter')}
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] hover:bg-[#00c853]/5 transition-all group"
              title="Share on Twitter"
            >
              <Twitter size={20} className="group-hover:scale-110 transition-transform" />
            </button>
            <button 
              onClick={() => handleShare('facebook')}
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] hover:bg-[#00c853]/5 transition-all group"
              title="Share on Facebook"
            >
              <Facebook size={20} className="group-hover:scale-110 transition-transform" />
            </button>
            <button 
              onClick={() => handleShare('linkedin')}
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] hover:bg-[#00c853]/5 transition-all group"
              title="Share on LinkedIn"
            >
              <Linkedin size={20} className="group-hover:scale-110 transition-transform" />
            </button>
            <button 
              onClick={() => handleShare()}
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-[#00c853] hover:border-[#00c853] hover:bg-[#00c853]/5 transition-all group"
              title="Copy Link"
            >
              <Share2 size={20} className="group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>

        {/* Read More Scroll Button */}
        <div className="flex justify-center mb-20">
          <button 
            onClick={() => relatedRef.current?.scrollIntoView({ behavior: 'smooth' })}
            className="group flex flex-col items-center space-y-2 text-white/40 hover:text-[#00c853] transition-colors"
          >
            <span className="text-[10px] uppercase font-black tracking-[0.3em]">Read More</span>
            <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center group-hover:border-[#00c853] transition-all">
              <ChevronRight size={20} className="rotate-90 group-hover:translate-y-1 transition-transform" />
            </div>
          </button>
        </div>

        {/* Read More Button */}
        {nextArticle && (
          <div className="flex justify-center mb-24">
            <Link 
              to={`/article/${nextArticle.slug}`}
              className="group flex flex-col items-center space-y-4"
            >
              <span className="text-[10px] uppercase font-black text-white/20 tracking-[0.4em]">Continue Reading</span>
              <div className="flex items-center space-x-6 bg-white/5 border border-white/10 px-12 py-6 rounded-full hover:border-[#00c853] transition-all group">
                <span className="mag-title text-2xl group-hover:text-[#00c853] transition-colors">Read Next Dispatch</span>
                <ArrowRight size={24} className="text-[#00c853] transform group-hover:translate-x-2 transition-transform" />
              </div>
            </Link>
          </div>
        )}

        {/* AI Summary Section */}
        {(summary || isSummarizing) && (
          <div className="mb-24 bg-[#00c853]/5 border border-[#00c853]/20 p-12 rounded-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Brain size={120} />
            </div>
            <div className="relative z-10">
              <div className="flex items-center space-x-3 mb-8">
                <div className="w-10 h-10 bg-[#00c853] flex items-center justify-center rounded-xl">
                  <Zap size={20} className="text-black" />
                </div>
                <div>
                  <h4 className="mag-title text-3xl">Neural Summary</h4>
                  <p className="text-[10px] uppercase font-black text-[#00c853] tracking-widest">AI-Generated Synthesis</p>
                </div>
              </div>
              {isSummarizing ? (
                <div className="space-y-4 animate-pulse">
                  <div className="h-4 bg-white/10 rounded w-full"></div>
                  <div className="h-4 bg-white/10 rounded w-5/6"></div>
                  <div className="h-4 bg-white/10 rounded w-4/6"></div>
                </div>
              ) : (
                <p className="text-2xl text-white/80 leading-relaxed font-serif italic">
                  {summary}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Related Articles Section */}
        <div className="border-t border-white/10 pt-20" ref={relatedRef}>
          <div className="flex items-center justify-between mb-16">
            <h4 className="mag-title text-5xl">Related Dispatches</h4>
            <div className="text-[10px] uppercase font-black text-[#00c853] tracking-widest">Powered by Gemini</div>
          </div>
          
          {isLoadingRelated ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="animate-pulse space-y-6">
                  <div className="aspect-video bg-white/5 rounded-2xl"></div>
                  <div className="h-4 bg-white/5 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {relatedArticles.slice(0, 4).map(art => (
                <ArticleCard key={art.id} article={art} variant="related" currentLang={globalLang} />
              ))}
            </div>
          )}
        </div>

        {analysis && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-24 p-12 bg-indigo-900/10 border border-indigo-500/20 rounded-3xl"
          >
            <div className="flex items-center space-x-4 mb-8">
              <div className="w-12 h-12 bg-indigo-600 flex items-center justify-center rounded-2xl">
                <Brain size={24} className="text-white" />
              </div>
              <div>
                <h3 className="mag-title text-3xl text-indigo-400">Deep Neural Analysis</h3>
                <p className="text-[10px] uppercase font-black text-indigo-400/60 tracking-widest">Thematic Synthesis</p>
              </div>
            </div>
            <div className="markdown-body text-xl leading-relaxed text-white/70 font-serif italic">
              <Markdown>{analysis}</Markdown>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

const AIStudio = ({ currentLang, logoUrl, setLogoUrl }: { currentLang: any, logoUrl: string | null, setLogoUrl: (url: string | null) => void }) => {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'image' | 'image-pro' | 'video' | 'search' | 'think' | 'edit' | 'analyze' | 'fast' | 'publish' | 'brand' | 'translate' | 'restyle'>('image');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState('Brutalist');
  const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0]);
  const [imgSize, setImgSize] = useState<"1K" | "2K" | "4K">("1K");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio?.hasSelectedApiKey();
      setHasKey(!!selected);
    };
    checkKey();
    // Check periodically or on focus
    const interval = setInterval(checkKey, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAction = async () => {
    setLoading(true);
    try {
      if (mode === 'image') {
        const url = await geminiService.generateImage(prompt, aspectRatio);
        setResult({ type: 'image', url });
      } else if (mode === 'image-pro') {
        const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio?.openSelectKey();
        }
        const url = await geminiService.generateImagePro(prompt, imgSize, aspectRatio);
        setResult({ type: 'image', url });
      } else if (mode === 'video') {
        const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio?.openSelectKey();
        }
        const url = await geminiService.generateVideo(prompt, selectedImage || undefined);
        setResult({ type: 'video', url });
      } else if (mode === 'search') {
        const data = await geminiService.chatWithSearch(prompt);
        setResult({ type: 'text', ...data });
      } else if (mode === 'think') {
        const text = await geminiService.think(prompt);
        setResult({ type: 'text', text });
      } else if (mode === 'fast') {
        const text = await geminiService.fastResponse(prompt);
        setResult({ type: 'text', text });
      } else if (mode === 'edit') {
        if (selectedImage) {
          const url = await geminiService.editImage(selectedImage, prompt);
          setResult({ type: 'image', url });
        }
      } else if (mode === 'analyze') {
        if (selectedImage) {
          const text = await geminiService.analyzeMedia(selectedImage, "image/png", prompt || "Analyze this image in detail.");
          setResult({ type: 'text', text });
        }
      } else if (mode === 'restyle') {
        if (selectedImage) {
          const url = await geminiService.editImage(selectedImage, `Re-style this image in a ${selectedStyle} aesthetic. ${prompt}`);
          setResult({ type: 'image', url });
        } else {
          const text = await geminiService.restyleText(prompt, selectedStyle);
          setResult({ type: 'text', text });
        }
      } else if (mode === 'translate') {
        const categoryArticles = MOCK_ARTICLES.filter(a => 
          a.categories?.includes(selectedCategory) || a.category === selectedCategory
        );
        if (categoryArticles.length > 0) {
          const article = categoryArticles[0];
          const textToTranslate = `# ${article.title}\n\n${article.content}`;
          const translatedText = await geminiService.translate(textToTranslate, currentLang.name);
          setResult({ type: 'text', text: translatedText });
        } else {
          setResult({ type: 'text', text: "No articles found in this category." });
        }
      } else if (mode === 'publish') {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Generate a full revolutionary magazine article based on this prompt: "${prompt}". 
          Return ONLY a JSON object with the following structure:
          {
            "title": "string",
            "dek": "string",
            "content": "string (Markdown)",
            "categories": ["string" (one or more of: ${CATEGORIES.join(', ')})],
            "tags": ["string"]
          }`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                dek: { type: Type.STRING },
                content: { type: Type.STRING },
                categories: { type: Type.ARRAY, items: { type: Type.STRING } },
                tags: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["title", "dek", "content", "categories", "tags"]
            }
          }
        });
        const articleData = JSON.parse(response.text.trim());
        const newArticle = {
          id: `art-${Date.now()}`,
          slug: articleData.title.toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-'),
          author: "Collective Intelligence",
          publishedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase(),
          image: `https://picsum.photos/seed/${Date.now()}/1200/800`,
          excerpt: articleData.dek,
          ...articleData
        };
        await dbService.createArticle(newArticle);
        setResult({ type: 'text', text: `Successfully published: **${newArticle.title}**\n\n[View Article](/article/${newArticle.slug})` });
      } else if (mode === 'brand') {
        const url = await geminiService.generateImage(
          prompt || "A minimalist, brutalist logo for a radical international news collective named 'granma'. Bold, high-contrast black and white design. Stylized typography with a subtle revolutionary star element. Clean lines, professional yet subversive aesthetic. Vector style, flat design, suitable for a high-end digital magazine header.",
          "1:1"
        );
        if (url) {
          setLogoUrl(url);
          localStorage.setItem('granma-logo', url);
          setResult({ type: 'image', url });
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-24 px-4 max-w-6xl mx-auto min-h-screen">
      <div className="text-center mb-12">
        <h1 className="mag-title text-7xl mb-4 text-[#00c853]">AI STUDIO</h1>
        <p className="text-white/40 uppercase tracking-[0.2em] text-xs">Collective Intelligence Laboratory</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          {[
            { id: 'image', label: 'Flash Image Gen', icon: <ImageIcon size={18} />, desc: 'Gemini 2.5 Flash Image' },
            { id: 'image-pro', label: 'Pro Image Gen', icon: <Sparkles size={18} />, desc: 'Gemini 3 Pro Image' },
            { id: 'edit', label: 'Image Editing', icon: <Sparkles size={18} />, desc: 'Gemini 2.5 Flash Image' },
            { id: 'analyze', label: 'Image Analysis', icon: <Scan size={18} />, desc: 'Gemini 3.1 Pro' },
            { id: 'video', label: 'Veo Video Gen', icon: <VideoIcon size={18} />, desc: 'Veo 3.1 Fast' },
            { id: 'search', label: 'Search Grounding', icon: <Search size={18} />, desc: 'Gemini 3 Flash' },
            { id: 'think', label: 'Thinking Mode', icon: <Brain size={18} />, desc: 'Gemini 3.1 Pro' },
            { id: 'fast', label: 'Fast Response', icon: <Zap size={18} />, desc: 'Gemini 2.5 Flash Lite' },
            { id: 'restyle', label: 'Artistic Re-style', icon: <Zap size={18} />, desc: 'Text or Image Transformation' },
            { id: 'translate', label: 'Category Translate', icon: <Languages size={18} />, desc: 'Gemini 2.5 Flash Lite' },
            { id: 'publish', label: 'Publish Dispatch', icon: <ArrowRight size={18} />, desc: 'AI-Generated Article' },
            { id: 'brand', label: 'Neural Brand', icon: <Fingerprint size={18} />, desc: 'Identity Generation' },
          ].map(m => (
            <button
              key={m.id}
              onClick={() => setMode(m.id as any)}
              className={cn(
                "w-full p-6 rounded-2xl border text-left transition-all group",
                mode === m.id 
                  ? "bg-[#00c853] border-[#00c853] text-black" 
                  : "bg-white/5 border-white/10 hover:border-[#00c853]/50"
              )}
            >
              <div className="flex items-center space-x-3 mb-2">
                {m.icon}
                <span className="street-heading text-lg">{m.label}</span>
              </div>
              <p className={cn("text-[10px] uppercase font-bold", mode === m.id ? "text-black/60" : "text-white/30")}>
                {m.desc}
              </p>
            </button>
          ))}
        </div>

        <div className="lg:col-span-2 space-y-8">
          {!hasKey && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-3xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-amber-500/20 rounded-2xl text-amber-500">
                  <Key size={24} />
                </div>
                <div>
                  <h4 className="street-heading text-lg text-amber-500">Premium Features Locked</h4>
                  <p className="text-xs text-white/40">High-res images and video generation require a paid Google Cloud project API key.</p>
                </div>
              </div>
              <button 
                onClick={() => (window as any).aistudio?.openSelectKey()}
                className="bg-amber-500 text-black px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-amber-400 transition-all"
              >
                Connect Paid Account
              </button>
            </div>
          )}

          <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
            {mode === 'image-pro' && (
              <div className="mb-6 grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs uppercase font-bold text-white/40 mb-2">Aspect Ratio</label>
                  <select 
                    value={aspectRatio} 
                    onChange={(e) => setAspectRatio(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm street-heading focus:border-[#00c853] outline-none"
                  >
                    {["1:1", "16:9", "9:16", "4:3", "3:4", "1:4", "1:8", "4:1", "8:1"].map(r => <option key={r} value={r} className="bg-[#0a0a0a]">{r}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs uppercase font-bold text-white/40 mb-2">Resolution</label>
                  <select 
                    value={imgSize} 
                    onChange={(e) => setImgSize(e.target.value as any)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm street-heading focus:border-[#00c853] outline-none"
                  >
                    {["1K", "2K", "4K"].map(s => <option key={s} value={s} className="bg-[#0a0a0a]">{s}</option>)}
                  </select>
                </div>
              </div>
            )}
            {mode === 'image' && (
              <div className="mb-6">
                <label className="block text-xs uppercase font-bold text-white/40 mb-2">Aspect Ratio</label>
                <select 
                  value={aspectRatio} 
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm street-heading focus:border-[#00c853] outline-none"
                >
                  {["1:1", "16:9", "9:16", "4:3", "3:4"].map(r => <option key={r} value={r} className="bg-[#0a0a0a]">{r}</option>)}
                </select>
              </div>
            )}
            {(mode === 'edit' || mode === 'analyze' || mode === 'video') && (
              <div className="mb-6">
                <label className="block text-xs uppercase font-bold text-white/40 mb-2">
                  {mode === 'video' ? 'Upload Reference Photo (Optional)' : 'Upload Image'}
                </label>
                <input type="file" onChange={handleImageUpload} className="w-full text-sm text-white/60 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-[#00c853] file:text-black hover:file:bg-[#00e676]" />
                {selectedImage && <img src={selectedImage} className="mt-4 h-32 rounded-lg border border-white/10" />}
              </div>
            )}
            {mode === 'video' && (
              <div className="mb-6">
                <label className="block text-xs uppercase font-bold text-white/40 mb-2">Aspect Ratio</label>
                <select 
                  value={aspectRatio} 
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm street-heading focus:border-[#00c853] outline-none"
                >
                  {["16:9", "9:16"].map(r => <option key={r} value={r} className="bg-[#0a0a0a]">{r}</option>)}
                </select>
              </div>
            )}
            {mode === 'translate' && (
              <div className="mb-6">
                <label className="block text-xs uppercase font-bold text-white/40 mb-2">Select Category to Translate</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={cn(
                        "text-[10px] p-2 rounded border transition-colors uppercase font-bold",
                        selectedCategory === cat 
                          ? "bg-[#00c853] border-[#00c853] text-black" 
                          : "bg-white/5 border-white/10 hover:border-[#00c853]/50"
                      )}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                <p className="mt-4 text-xs text-white/40 italic">
                  Translating the latest article in <span className="text-[#00c853] font-bold">{selectedCategory}</span> into <span className="text-[#00c853] font-bold">{currentLang.name}</span>.
                </p>
              </div>
            )}
            {mode === 'restyle' && (
              <div className="mb-6 space-y-6">
                <div>
                  <label className="block text-xs uppercase font-bold text-white/40 mb-3 tracking-widest">Select Artistic Style</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {AI_STYLES.map(s => (
                      <button
                        key={s.name}
                        onClick={() => setSelectedStyle(s.name)}
                        className={cn(
                          "p-3 rounded-xl border text-left transition-all",
                          selectedStyle === s.name 
                            ? "bg-[#00c853] border-[#00c853] text-black" 
                            : "bg-white/5 border-white/10 hover:border-[#00c853]/50"
                        )}
                      >
                        <span className="block text-[10px] font-black uppercase mb-1">{s.name}</span>
                        <span className={cn("block text-[8px] opacity-60", selectedStyle === s.name ? "text-black" : "text-white")}>{s.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs uppercase font-bold text-white/40 mb-2">Optional: Upload Image to Re-style</label>
                  <input type="file" onChange={handleImageUpload} className="w-full text-sm text-white/60 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-[#00c853] file:text-black hover:file:bg-[#00e676]" />
                  {selectedImage && <img src={selectedImage} className="mt-4 h-32 rounded-lg border border-white/10" />}
                  {!selectedImage && <p className="mt-2 text-[10px] text-white/20 uppercase font-bold italic">No image uploaded? We will re-style the text prompt instead.</p>}
                </div>
              </div>
            )}
            {mode === 'brand' && (
              <div className="mb-6">
                <label className="block text-xs uppercase font-bold text-white/40 mb-4 tracking-widest">Current Neural Identity</label>
                <div className="flex items-center space-x-8">
                  {logoUrl ? (
                    <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-[#00c853] shadow-[0_0_30px_rgba(0,200,83,0.3)]">
                      <img src={logoUrl} className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="w-32 h-32 rounded-full bg-white/5 border-2 border-dashed border-white/20 flex items-center justify-center">
                      <Fingerprint size={32} className="text-white/20" />
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="street-heading text-xl mb-2">Neural Brand Engine</h4>
                    <p className="text-xs text-white/40 leading-relaxed mb-4">
                      The collective's visual identity is fluid, generated by neural networks to reflect our evolving mission. 
                      Use the prompt below to refine the aesthetic or re-generate the mark.
                    </p>
                    <div className="flex items-center space-x-2 text-[10px] font-black uppercase text-[#00c853]">
                      <Zap size={12} />
                      <span>Gemini 3 Pro Vision Active</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                mode === 'edit' ? "Describe the changes (e.g., 'Add a retro filter')" : 
                mode === 'restyle' ? (selectedImage ? "Additional instructions for the image re-style..." : "Enter text to be re-styled...") :
                mode === 'translate' ? "Add specific translation instructions (optional)..." : 
                `Enter prompt for ${mode}...`
              }
              className="w-full bg-black/40 border border-white/10 rounded-2xl p-6 min-h-[150px] focus:outline-none focus:border-[#00c853] text-lg mb-6"
            />
            <button
              onClick={handleAction}
              disabled={loading || (mode !== 'translate' && !prompt) || (mode === 'edit' && !selectedImage)}
              className={cn(
                "w-full py-4 rounded-2xl font-black text-xl transition-all disabled:opacity-50 flex items-center justify-center space-x-3 overflow-hidden relative",
                loading && mode === 'think' ? "bg-indigo-600 text-white animate-pulse" : "bg-[#00c853] text-black hover:bg-[#00e676]"
              )}
            >
              {loading ? (
                <div className="flex items-center space-x-3">
                  {mode === 'think' ? (
                    <>
                      <Brain className="animate-bounce" size={24} />
                      <span className="tracking-[0.2em]">SYNTHESIZING THOUGHT...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="animate-pulse" />
                      <span>PROCESSING...</span>
                    </>
                  )}
                </div>
              ) : (
                <>
                  <Sparkles size={24} />
                  <span>GENERATE</span>
                </>
              )}
            </button>
          </div>

          <AnimatePresence mode="wait">
            {loading && mode === 'think' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-indigo-900/20 border border-indigo-500/30 rounded-3xl p-8 text-center space-y-6"
              >
                <div className="relative w-20 h-20 mx-auto">
                  <div className="absolute inset-0 bg-indigo-500 rounded-full animate-ping opacity-20"></div>
                  <div className="absolute inset-2 bg-indigo-500 rounded-full animate-pulse opacity-40"></div>
                  <div className="relative z-10 w-full h-full flex items-center justify-center text-indigo-400">
                    <Brain size={40} />
                  </div>
                </div>
                <div>
                  <h3 className="street-heading text-xl text-indigo-400 mb-2">DEEP NEURAL SYNTHESIS</h3>
                  <p className="text-xs text-white/40 uppercase tracking-widest font-mono">Gemini 3.1 Pro is navigating complex thematic layers...</p>
                </div>
                <div className="flex justify-center space-x-1">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-1.5 h-1.5 bg-indigo-500 rounded-full"
                      animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {result && !loading && (
              <motion.div
                key={JSON.stringify(result)}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white/5 border border-white/10 rounded-3xl p-8 overflow-hidden"
              >
                {result.type === 'image' && (
                  <img src={result.url} alt="Generated" className="w-full rounded-xl" />
                )}
                {result.type === 'video' && (
                  <div className="aspect-video bg-black rounded-xl flex items-center justify-center text-white/40">
                    <div className="text-center p-8">
                      <VideoIcon size={48} className="mx-auto mb-4" />
                      <p className="mb-4">Video generated successfully.</p>
                      <a href={result.url} target="_blank" className="text-[#00c853] underline">Download Video</a>
                    </div>
                  </div>
                )}
                {result.type === 'text' && (
                  <div className="prose prose-invert max-w-none">
                    <Markdown>{result.text}</Markdown>
                    {result.sources && result.sources.length > 0 && (
                      <div className="mt-8 pt-8 border-t border-white/10">
                        <h4 className="street-heading text-xs text-white/30 mb-4">Sources</h4>
                        <div className="flex flex-wrap gap-2">
                          {result.sources.map((s: string, i: number) => (
                            <a key={i} href={s} target="_blank" className="text-[10px] bg-white/5 px-2 py-1 rounded hover:bg-[#00c853] hover:text-black transition-colors">
                              {new URL(s).hostname}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const LiveAssistant = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);

  const startListening = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      
      setIsListening(true);
      setTranscript("Listening to the streets...");

      const session = await ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-09-2025",
        config: {
          systemInstruction: "You are the voice of the granma collective. You are radical, intelligent, and deeply committed to revolutionary thought and radical ecology. Speak with a calm but firm authority.",
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } }
          }
        },
        callbacks: {
          onopen: () => {
            // Setup audio capture
            audioContextRef.current = new AudioContext({ sampleRate: 16000 });
            const source = audioContextRef.current.createMediaStreamSource(stream);
            const processor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            
            source.connect(processor);
            processor.connect(audioContextRef.current.destination);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              // Convert to 16-bit PCM
              const pcmData = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
              }
              const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
              session.sendRealtimeInput({
                media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
              });
            };
          },
          onmessage: async (message) => {
            if (message.serverContent?.modelTurn) {
              const part = message.serverContent.modelTurn.parts[0];
              if (part?.inlineData) {
                // Handle audio output
                const base64Audio = part.inlineData.data;
                const audioData = Uint8Array.from(atob(base64Audio), c => c.charCodeAt(0));
                // Play audio (simplified for demo)
                const blob = new Blob([audioData], { type: 'audio/pcm' });
                const url = URL.createObjectURL(blob);
                const audio = new Audio(url);
                audio.play();
                setIsSpeaking(true);
                audio.onended = () => setIsSpeaking(false);
              }
              if (part?.text) {
                setResponse(prev => prev + part.text);
              }
            }
          },
          onclose: () => {
            setIsListening(false);
            if (audioContextRef.current) audioContextRef.current.close();
          },
          onerror: (e) => {
            console.error("Live API Error:", e);
            setIsListening(false);
          }
        }
      });
      
      sessionRef.current = session;
    } catch (e) {
      console.error("Failed to start Live Assistant:", e);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
    }
    setIsListening(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="fixed bottom-28 right-8 w-96 bg-[#111] border border-white/10 rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col max-h-[600px]"
        >
          <div className="p-6 border-b border-white/10 flex items-center justify-between bg-[#00c853] text-black">
            <div className="flex items-center space-x-2">
              <Sparkles size={20} />
              <h3 className="street-heading text-lg">COLLECTIVE VOICE</h3>
            </div>
            <button onClick={onClose} className="hover:bg-black/10 p-1 rounded-full">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 p-6 overflow-y-auto space-y-6">
            {transcript && (
              <div className="bg-white/5 p-4 rounded-2xl rounded-tr-none ml-8">
                <p className="text-xs text-white/30 uppercase mb-1">You</p>
                <p className="text-sm">{transcript}</p>
              </div>
            )}
            {response && (
              <div className="bg-[#00c853]/10 p-4 rounded-2xl rounded-tl-none mr-8 border border-[#00c853]/20">
                <p className="text-xs text-[#00c853] uppercase mb-1">Collective</p>
                <div className="text-sm prose prose-invert prose-sm">
                  <Markdown>{response}</Markdown>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 bg-black/40 border-t border-white/10 flex flex-col items-center space-y-4">
            <button 
              onClick={isListening ? stopListening : startListening}
              className={cn(
                "w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-lg",
                isListening ? "bg-red-500 animate-pulse" : "bg-[#00c853] hover:scale-105"
              )}
            >
              {isListening ? <StopCircle size={32} /> : <Mic size={32} className="text-black" />}
            </button>
            <p className="text-[10px] uppercase font-bold text-white/40 tracking-widest">
              {isListening ? "LISTENING TO THE STREETS..." : isSpeaking ? "SPEAKING..." : "TAP TO SPEAK"}
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const Gallery = ({ currentLang }: { currentLang: any }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [visibleCount, setVisibleCount] = useState(12);
  const loaderRef = useRef<HTMLDivElement>(null);
  const { t } = useTranslation(currentLang.code);

  const allImages = MOCK_ARTICLES.map(a => ({ 
    url: a.image, 
    title: a.title, 
    category: a.categories ? a.categories[0] : a.category 
  }));

  const filteredImages = selectedCategory === 'all' 
    ? allImages 
    : allImages.filter(img => img.category?.toLowerCase() === selectedCategory.toLowerCase());

  const visibleImages = filteredImages.slice(0, visibleCount);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && visibleCount < filteredImages.length) {
          setVisibleCount(prev => prev + 8);
        }
      },
      { threshold: 1.0 }
    );

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => observer.disconnect();
  }, [visibleCount, filteredImages.length]);

  useSEO({
    title: t('visual_archive'),
    description: t('collective_memory'),
    keywords: "revolutionary art, radical photography, collective archive"
  });

  return (
    <div className="pt-24 px-4 max-w-7xl mx-auto min-h-screen">
      <div className="mb-12 border-b border-white/10 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div>
          <h1 className="mag-title text-6xl mb-4">{t('visual_archive')}</h1>
          <p className="text-white/40 uppercase tracking-widest text-xs">{t('collective_memory')}</p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => { setSelectedCategory('all'); setVisibleCount(12); }}
            className={cn(
              "px-4 py-2 rounded-full text-[10px] uppercase font-black tracking-widest transition-all border",
              selectedCategory === 'all' ? "bg-[#00c853] border-[#00c853] text-black" : "bg-white/5 border-white/10 text-white/40 hover:border-[#00c853]/50"
            )}
          >
            All
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => { setSelectedCategory(cat); setVisibleCount(12); }}
              className={cn(
                "px-4 py-2 rounded-full text-[10px] uppercase font-black tracking-widest transition-all border",
                selectedCategory === cat ? "bg-[#00c853] border-[#00c853] text-black" : "bg-white/5 border-white/10 text-white/40 hover:border-[#00c853]/50"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
        {visibleImages.map((img, i) => (
          <motion.div
            key={`${img.url}-${i}`}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="break-inside-avoid group relative rounded-2xl overflow-hidden cursor-pointer"
          >
            <OptimizedImage 
              src={img.url} 
              alt={img.title} 
              aspectRatio="auto"
              variant="clean"
            />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
              <span className="text-[10px] uppercase font-bold text-[#00c853] mb-1">
                {img.category}
              </span>
              <h3 className="street-heading text-lg leading-tight">{img.title}</h3>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Loader for Infinite Scroll */}
      <div ref={loaderRef} className="h-20 flex items-center justify-center mt-12">
        {visibleCount < filteredImages.length && (
          <div className="w-6 h-6 border-2 border-[#00c853] border-t-transparent rounded-full animate-spin"></div>
        )}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('granma-theme');
    return (saved as 'dark' | 'light') || 'dark';
  });
  const [lang, setLang] = useState(() => {
    const saved = localStorage.getItem('granma-lang');
    if (saved) {
      const found = LANGUAGES.find(l => l.code === saved);
      if (found) return found;
    }
    return LANGUAGES[0];
  });
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPGNpcmNsZSBjeD0iMTAwIiBjeT0iMTAwIiByPSI5MCIgZmlsbD0iYmxhY2siIC8+CiAgPHRleHQgeD0iNTAlIiB5PSI1NSUiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0ic2Fucy1zZXJpZiIgZm9udC1zaXplPSI2MCIgZm9udC13ZWlnaHQ9ImJvbGQiPuகுரல்PC90ZXh0PgogIDxjaXJjbGUgY3g9IjE0NSIgY3k9Ijg1IiByPSIxMCIgZmlsbD0icmVkIiAvPgo8L3N2Zz4=");

  useEffect(() => {
    const fetchLogo = async () => {
      const savedLogo = localStorage.getItem('granma-logo');
      if (savedLogo) {
        setLogoUrl(savedLogo);
      }
    };
    fetchLogo();
  }, []);

  useEffect(() => {
    document.body.className = theme;
    document.documentElement.dir = lang.dir;
    localStorage.setItem('granma-theme', theme);
    localStorage.setItem('granma-lang', lang.code);
  }, [theme, lang]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  return (
    <Router>
      <div className={cn("min-h-screen font-sans selection:bg-[#00c853] selection:text-black", theme === 'light' && "light")}>
        <Navbar theme={theme} toggleTheme={toggleTheme} currentLang={lang} setLang={setLang} logoUrl={logoUrl} />
        
        <main className="pb-20">
          <Routes>
            <Route path="/" element={<Home currentLang={lang} />} />
            <Route path="/gallery" element={<Gallery currentLang={lang} />} />
            <Route path="/article/:slug" element={<ArticlePage currentLang={lang} />} />
            <Route path="/studio" element={<AIStudio currentLang={lang} logoUrl={logoUrl} setLogoUrl={setLogoUrl} />} />
            <Route path="/category/:category" element={<Home currentLang={lang} />} />
          </Routes>
        </main>

        <Footer currentLang={lang} logoUrl={logoUrl} />
        
        {/* Global AI Trigger */}
        <div className="fixed bottom-8 right-8 z-50">
          <button 
            onClick={() => setIsAssistantOpen(!isAssistantOpen)}
            className="w-16 h-16 bg-[#00c853] text-black rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-transform group"
          >
            <Sparkles size={28} className="group-hover:rotate-12 transition-transform" />
            <div className="absolute right-full mr-4 bg-black border border-white/10 px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              {useTranslation(lang.code).t('ask_collective')}
            </div>
          </button>
        </div>

        <LiveAssistant isOpen={isAssistantOpen} onClose={() => setIsAssistantOpen(false)} />
      </div>
    </Router>
  );
}
