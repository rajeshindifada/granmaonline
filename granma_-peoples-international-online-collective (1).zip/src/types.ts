export interface LanguageConfig {
  code: string;
  name: string;
  native: string;
  dir: 'ltr' | 'rtl';
  enabled: boolean;
}

export enum Category {
  CLASS_STRUGGLE = 'class struggle',
  CASTE_SOCIETY = 'caste & society',
  FEMINISM = 'feminism',
  ANTIRACISM = 'antiracism',
  NATIONALITIES = 'nationalities',
  ECOLOGY = 'ecology',
  ASTRONOMY = 'astronomy',
  RADICAL_SPORTS = 'radical sports'
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  dek: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  categories?: string[];
  date: string;
  publishedAt: string;
  image: string;
  imageUrl: string;
  tags: string[];
}
