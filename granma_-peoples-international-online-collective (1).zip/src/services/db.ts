export const dbService = {
  async getArticles() {
    const response = await fetch("/api/articles");
    if (!response.ok) throw new Error("Failed to fetch articles");
    const data = await response.json();
    return data.map((art: any) => ({
      ...art,
      categories: art.categories ? JSON.parse(art.categories) : [],
      tags: art.tags ? JSON.parse(art.tags) : []
    }));
  },

  async getArticleBySlug(slug: string) {
    const response = await fetch(`/api/articles/${slug}`);
    if (!response.ok) throw new Error("Failed to fetch article");
    const data = await response.json();
    return {
      ...data,
      categories: data.categories ? JSON.parse(data.categories) : [],
      tags: data.tags ? JSON.parse(data.tags) : []
    };
  },

  async createArticle(article: any) {
    const response = await fetch("/api/articles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(article)
    });
    if (!response.ok) throw new Error("Failed to create article");
    return response.json();
  },

  async saveTranslation(articleId: string, langCode: string, translation: { title: string; dek: string; content: string }) {
    const response = await fetch("/api/translations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        article_id: articleId,
        lang_code: langCode,
        ...translation
      })
    });
    if (!response.ok) throw new Error("Failed to save translation");
    return response.json();
  },

  async updateArticleImage(articleId: string, image: string, prompt: string) {
    const response = await fetch(`/api/articles/${articleId}/image`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image, image_prompt: prompt })
    });
    if (!response.ok) throw new Error("Failed to update article image");
    return response.json();
  }
};
