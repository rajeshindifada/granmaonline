import { GoogleGenAI, Type, ThinkingLevel, Modality } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const geminiService = {
  // Basic chat with Search Grounding
  async chatWithSearch(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(c => c.web?.uri).filter(Boolean) || []
    };
  },

  // Complex reasoning with Thinking Mode
  async think(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
      }
    });
    return response.text;
  },

  // Fast response with Flash Lite
  async fastResponse(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite-latest",
      contents: prompt,
    });
    return response.text;
  },

  // Image Generation with Flash (Free, no user key required)
  async generateImage(prompt: string, aspectRatio: string = "1:1") {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio,
        },
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // High-Quality Image Generation (Requires user-provided API key)
  async generateImagePro(prompt: string, size: "1K" | "2K" | "4K" = "1K", aspectRatio: string = "1:1") {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
          imageSize: size
        },
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // Image Editing with Flash Image
  async editImage(base64Image: string, prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Image.split(',')[1], mimeType: "image/png" } },
          { text: prompt },
        ],
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // Image/Video Analysis
  async analyzeMedia(base64Data: string, mimeType: string, prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: {
        parts: [
          { inlineData: { data: base64Data.split(',')[1], mimeType } },
          { text: prompt },
        ]
      },
    });
    return response.text;
  },

  // TTS
  async generateSpeech(text: string, voice: string = 'Kore') {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  },

  // Translation
  async translate(data: string | { title: string; dek: string; content: string }, targetLanguage: string) {
    const ai = getAI();
    
    if (typeof data === 'string') {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-lite-latest",
        contents: `Translate the following text into ${targetLanguage}. Maintain the tone and formatting (Markdown): \n\n${data}`,
      });
      return response.text;
    } else {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-lite-latest",
        contents: `Translate the following article parts into ${targetLanguage}. Maintain the tone and formatting (Markdown).
        
        TITLE: ${data.title}
        DEK: ${data.dek}
        CONTENT: ${data.content}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              dek: { type: Type.STRING },
              content: { type: Type.STRING }
            },
            required: ["title", "dek", "content"]
          }
        }
      });
      return JSON.parse(response.text.trim());
    }
  },

  // Deep Analysis
  async analyzeArticle(content: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: `Perform a deep thematic and socio-political analysis of the following article. 
      Identify revolutionary themes, radical ecological impacts, and the broader context of the struggle it describes.
      Return the analysis in Markdown format.
      
      CONTENT: ${content}`,
    });
    return response.text;
  },

  // Suggest Related Articles
  async getRelatedArticles(currentArticle: any, allArticles: any[]) {
    const ai = getAI();
    const articlesMetadata = allArticles.map(a => ({ 
      id: a.id, 
      title: a.title, 
      category: a.category, 
      author: a.author,
      tags: a.tags 
    }));
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Given the current article: "${currentArticle.title}" in category "${currentArticle.category}" by "${currentArticle.author}" with tags: [${currentArticle.tags?.join(', ')}].
      Suggest the 5 most related articles from this list based on content similarity, author, category, or shared tags. 
      For each suggestion, provide a very short (3-5 words) reason why it was recommended (e.g., "Shared focus on Radical Ecology").
      Return a JSON array of objects with "id" and "reason" properties.
      
      List of articles:
      ${JSON.stringify(articlesMetadata)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { 
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["id", "reason"]
          }
        }
      }
    });
    
    try {
      const recommendations = JSON.parse(response.text.trim());
      return recommendations.map((rec: any) => {
        const art = allArticles.find(a => a.id === rec.id);
        if (art && art.id !== currentArticle.id) {
          return { ...art, recommendationReason: rec.reason };
        }
        return null;
      }).filter(Boolean);
    } catch (e) {
      console.error("Failed to parse related articles:", e);
      return [];
    }
  },

  // Imagen 4.0 Generation (Requires user-provided API key)
  async generateImages(prompt: string, aspectRatio: string = "1:1") {
    const ai = getAI();
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt,
      config: {
        numberOfImages: 1,
        aspectRatio: aspectRatio as any,
      },
    });
    
    const base64 = response.generatedImages[0].image.imageBytes;
    return `data:image/png;base64,${base64}`;
  },

  // Restyle Text
  async restyleText(text: string, style: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Rewrite the following text in the style of "${style}". Maintain the core meaning but completely transform the tone, vocabulary, and structure to match the requested style. \n\nTEXT: ${text}`,
    });
    return response.text;
  },

  // Video Generation (Veo)
  async generateVideo(prompt: string, base64Image?: string, aspectRatio: '16:9' | '9:16' = '16:9') {
    const ai = getAI();
    const config: any = {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio
    };

    const params: any = {
      model: 'veo-3.1-fast-generate-preview',
      prompt,
      config
    };

    if (base64Image) {
      params.image = {
        imageBytes: base64Image.split(',')[1],
        mimeType: 'image/png'
      };
    }

    let operation = await ai.models.generateVideos(params);

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    return downloadLink;
  },

  // Generate Summary
  async generateSummary(content: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize the following article content in 3-4 concise, powerful sentences that capture its core revolutionary or socio-political message. \n\nCONTENT: ${content}`,
    });
    return response.text;
  },
};
