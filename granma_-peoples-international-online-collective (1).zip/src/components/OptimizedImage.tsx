import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  aspectRatio?: 'video' | 'square' | 'portrait' | 'editorial' | 'auto';
  containerClassName?: string;
  overlay?: React.ReactNode;
  variant?: 'clean' | 'bold' | 'minimal';
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({ 
  src, 
  alt, 
  className, 
  containerClassName,
  aspectRatio = 'video',
  overlay,
  variant = 'clean',
  ...props 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);

  const ratioClasses = {
    video: 'aspect-[16/9]',
    square: 'aspect-square',
    portrait: 'aspect-[3/4]',
    editorial: 'aspect-[4/3]',
    auto: '',
  };

  const variantClasses = {
    clean: 'rounded-2xl shadow-lg',
    bold: 'rounded-none border border-white/5 shadow-[0_20px_50px_rgba(0,0,0,0.5)]',
    minimal: 'rounded-none',
  };

  // Generate a low-res placeholder URL
  const getPlaceholderUrl = (originalSrc: string | undefined) => {
    if (!originalSrc) return '';
    
    try {
      if (originalSrc.includes('unsplash.com')) {
        // Unsplash: Replace width/height or append small dimensions
        const url = new URL(originalSrc);
        url.searchParams.set('w', '50');
        url.searchParams.set('q', '30');
        url.searchParams.set('blur', '10');
        return url.toString();
      }
      
      if (originalSrc.includes('picsum.photos')) {
        // Picsum: Replace dimensions with small ones
        // Example: https://picsum.photos/seed/future/1200/800 -> https://picsum.photos/seed/future/50/50
        return originalSrc.replace(/\/\d+\/\d+/, '/50/50') + (originalSrc.includes('?') ? '&blur=2' : '?blur=2');
      }
    } catch (e) {
      return originalSrc;
    }
    
    return originalSrc;
  };

  const placeholderUrl = getPlaceholderUrl(src);

  return (
    <div className={cn(
      "relative overflow-hidden bg-zinc-900 group",
      ratioClasses[aspectRatio],
      variantClasses[variant],
      containerClassName
    )}>
      {/* Blurred Placeholder */}
      <AnimatePresence>
        {!isLoaded && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-10"
          >
            {placeholderUrl && (
              <img 
                src={placeholderUrl} 
                alt="" 
                className="w-full h-full object-cover blur-2xl scale-110 opacity-50"
                referrerPolicy="no-referrer"
              />
            )}
            <div className="absolute inset-0 shimmer-sweep opacity-30" />
          </motion.div>
        )}
      </AnimatePresence>

      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
        className={cn(
          "w-full h-full object-cover transition-all duration-700 ease-out",
          isLoaded ? "opacity-100 scale-100 blur-0" : "opacity-0 scale-105 blur-lg",
          variant === 'clean' && "group-hover:scale-105",
          variant === 'bold' && "group-hover:scale-[1.02] contrast-[1.1] saturate-[1.1]",
          className
        )}
        referrerPolicy="no-referrer"
        {...props}
      />

      {/* Overlay */}
      {overlay && (
        <div className="absolute inset-0 z-20 pointer-events-none">
          {overlay}
        </div>
      )}
      
      {/* Subtle Gradient for Bold Variant */}
      {variant === 'bold' && !overlay && (
        <div className="absolute inset-0 z-10 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
      )}
    </div>
  );
};
