import { LanguageConfig, Article } from '../types';
import { COLORS, CATEGORIES, LANGUAGES } from '../constants';

export { COLORS, CATEGORIES, LANGUAGES };

export const MOCK_ARTICLES: Article[] = Array.from({ length: 21 }).map((_, i) => {
  const category = CATEGORIES[i % CATEGORIES.length];
  
  const thematicData = [
    {
      title: 'every defeat contains its own seed of victory',
      dek: 'Malcolm X on the lessons found in loss and the path to future performance.',
      image: 'https://images.unsplash.com/photo-1590073844006-3a44279d6df7'
    },
    {
      title: 'i am for truth, no matter who tells it',
      dek: 'The radical philosophy of Malcolm X: justice is for or against, with no middle ground.',
      image: 'https://images.unsplash.com/photo-1584483766114-2cea6facdf57'
    },
    {
      title: 'your enemy is not the refugee',
      dek: 'Willie Nelson on identifying the true source of displacement and the importance of international solidarity.',
      image: 'https://images.unsplash.com/photo-1543116224-1a97572224fd'
    },
    {
      title: 'the vulture and the silence',
      dek: 'Revisiting the ethical weight of global inequality and the images that haunt our collective conscience.',
      image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c'
    },
    {
      title: 'resistance in the heart of the empire',
      dek: 'Protesters reclaim the streets against the rising tide of authoritarianism and hate.',
      image: 'https://images.unsplash.com/photo-1516211697129-83d24df54f46'
    },
    {
      title: 'nazi trumps fuck off',
      dek: 'The uncompromising language of the streets in the battle against fascist resurgence.',
      image: 'https://images.unsplash.com/photo-1494145904049-0dca59b4bbad'
    },
    {
      title: 'the eternal flame of che guevara',
      dek: 'How the image of the revolutionary continues to inspire movements across the global south.',
      image: 'https://images.unsplash.com/photo-1605142859862-978be7eba909'
    },
    {
      title: 'radical ecology: the green path',
      dek: 'Walking through the ancient forests that hold the secrets to our planetary survival.',
      image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e'
    },
    {
      title: 'silhouettes of the living earth',
      dek: 'The intricate patterns of nature as a blueprint for decentralized resistance.',
      image: 'https://images.unsplash.com/photo-1501854140801-50d01674db4e'
    },
    {
      title: 'the stream of collective consciousness',
      dek: 'Water as a metaphor for the fluid and unstoppable nature of people power.',
      image: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d'
    },
    {
      title: 'the buddha in the leaf',
      dek: 'Finding the intersection of radical mindfulness and ecological preservation.',
      image: 'https://images.unsplash.com/photo-1545305836-3a21503f1fd0'
    },
    {
      title: 'vibrant identities: the art of the hair',
      dek: 'How graffiti and portraiture merge to celebrate the beauty of the diaspora.',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb'
    },
    {
      title: 'the colors of resistance',
      dek: 'Bold visual narratives that challenge traditional standards of beauty and power.',
      image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce'
    },
    {
      title: 'afro-futurism and the digital commons',
      dek: 'Reclaiming the future through a synthesis of heritage and high-tech imagination.',
      image: 'https://images.unsplash.com/photo-1523961131990-5ea7c61b2107'
    },
    {
      title: 'mother earth in our hands',
      dek: 'The responsibility of stewardship in an era of unprecedented ecological crisis.',
      image: 'https://images.unsplash.com/photo-1526772662000-3f88f10405ff'
    },
    {
      title: 'long live com. basavraj',
      dek: 'The enduring legacy of revolutionary leaders in the subaltern struggles of india.',
      image: 'https://images.unsplash.com/photo-1523733566457-60d397a7d057'
    },
    {
      title: 'the wisdom of the elders',
      dek: 'Translating the radical traditions of the past into the languages of the present.',
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d'
    },
    {
      title: 'women at the frontlines',
      dek: 'The indispensable role of women in the history and future of radical social change.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2'
    },
    {
      title: 'blueprints for a new world',
      dek: 'Deep thinking and strategic planning for the post-capitalist transition.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d'
    },
    {
      title: 'the brazilian soul',
      dek: 'Artistic expressions of identity and struggle from the heart of south america.',
      image: 'https://images.unsplash.com/photo-1520156555810-664405323931'
    },
    {
      title: 'the skeleton of the old world',
      dek: 'The dying structures of the past making way for the vibrant green of the future.',
      image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef'
    }
  ];

  const currentData = thematicData[i];
  const imageUrl = `${currentData.image}?q=80&w=1200&auto=format&fit=crop`;
  
  return {
    id: `art-${i}`,
    title: currentData.title,
    slug: `article-${i}`,
    dek: currentData.dek,
    excerpt: currentData.dek,
    content: `long form content about revolutionary theory and practice... the struggle continues in every corner of the globe. \n\n![street resistance in the global south](${imageUrl})\n\nfrom the streets of the global south to the digital commons, new forms of collective intelligence are emerging. we must nurture these seeds of change, building networks of solidarity that transcend borders and ideologies. \n\n![digital solidarity networks](${imageUrl})\n\nour future is not written in the boardrooms of capital, but in the hearts and minds of the people.`,
    author: 'radical voice',
    category,
    categories: [category],
    date: '2026-10-12',
    publishedAt: 'october 12, 2026',
    image: imageUrl,
    imageUrl: imageUrl,
    tags: ['radical', 'future', 'struggle']
  };
});
