import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("granma.db");

// Initialize Database
db.exec(`
  DROP TABLE IF EXISTS articles;
  DROP TABLE IF EXISTS translations;

  CREATE TABLE IF NOT EXISTS articles (
    id TEXT PRIMARY KEY,
    slug TEXT UNIQUE,
    title TEXT,
    author TEXT,
    categories TEXT,
    publishedAt TEXT,
    image TEXT,
    dek TEXT,
    excerpt TEXT,
    content TEXT,
    tags TEXT,
    image_prompt TEXT
  );

  CREATE TABLE IF NOT EXISTS translations (
    article_id TEXT,
    lang_code TEXT,
    title TEXT,
    dek TEXT,
    content TEXT,
    PRIMARY KEY (article_id, lang_code),
    FOREIGN KEY (article_id) REFERENCES articles(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/articles", (req, res) => {
    const articles = db.prepare("SELECT * FROM articles").all();
    res.json(articles);
  });

  app.get("/api/articles/:slug", (req, res) => {
    const article = db.prepare("SELECT * FROM articles WHERE slug = ?").get(req.params.slug);
    if (!article) return res.status(404).json({ error: "Article not found" });

    const translations = db.prepare("SELECT * FROM translations WHERE article_id = ?").all(article.id);
    res.json({ ...article, translations });
  });

  app.post("/api/articles", (req, res) => {
    const { id, slug, title, author, categories, publishedAt, image, dek, excerpt, content, tags, image_prompt } = req.body;
    
    try {
      const stmt = db.prepare(`
        INSERT INTO articles (id, slug, title, author, categories, publishedAt, image, dek, excerpt, content, tags, image_prompt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(id, slug, title, author, JSON.stringify(categories || []), publishedAt, image, dek, excerpt, content, JSON.stringify(tags || []), image_prompt);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.patch("/api/articles/:id/image", (req, res) => {
    const { image, image_prompt } = req.body;
    const { id } = req.params;

    try {
      const stmt = db.prepare(`
        UPDATE articles 
        SET image = ?, image_prompt = ?
        WHERE id = ?
      `);
      const result = stmt.run(image, image_prompt, id);
      if (result.changes === 0) return res.status(404).json({ error: "Article not found" });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.post("/api/translations", (req, res) => {
    const { article_id, lang_code, title, dek, content } = req.body;
    
    try {
      const stmt = db.prepare(`
        INSERT OR REPLACE INTO translations (article_id, lang_code, title, dek, content)
        VALUES (?, ?, ?, ?, ?)
      `);
      stmt.run(article_id, lang_code, title, dek, content);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Seed data if empty
  const count = db.prepare("SELECT COUNT(*) as count FROM articles").get().count;
  if (count === 0) {
    console.log("Seeding database...");
    
    // Define a few seed articles with tags
    const seedArticles = [
      {
        id: "1",
        slug: "the-future-of-collective-intelligence",
        title: "The Future of Collective Intelligence",
        author: "The Collective",
        categories: JSON.stringify(["Politics", "Collective Intelligence"]),
        publishedAt: "FEB 24, 2026",
        image: "https://images.unsplash.com/photo-1590073844006-3a44279d6df7?q=80&w=1200&auto=format&fit=crop",
        dek: "How decentralization is reshaping the way we think and act together.",
        excerpt: "The rise of decentralized networks is not just a technological shift...",
        content: "# The Future of Collective Intelligence\n\nIn the heart of the digital revolution lies a seed of radical change. Collective intelligence is no longer a theoretical concept; it is a lived reality. From decentralized autonomous organizations (DAOs) to open-source intelligence networks, the way we coordinate and create value is being fundamentally transformed.\n\n![Collective Intelligence](https://images.unsplash.com/photo-1590073844006-3a44279d6df7?q=80&w=1200&auto=format&fit=crop)\n\nThis shift is not merely technical. It is deeply political. By removing central points of failure and control, we are building systems that are inherently more resilient and democratic. The challenge now is to ensure these tools are accessible to all, not just a technocratic elite.",
        tags: JSON.stringify(["intelligence", "future", "politics", "decentralization"])
      },
      {
        id: "2",
        slug: "radical-ecology-the-green-path",
        title: "Radical Ecology: The Green Path",
        author: "Eco Warrior",
        categories: JSON.stringify(["World", "Radical Ecology"]),
        publishedAt: "FEB 25, 2026",
        image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop",
        dek: "Walking through the ancient forests that hold the secrets to our planetary survival.",
        excerpt: "The forests are not just lungs; they are libraries of ancient wisdom...",
        content: "# Radical Ecology\n\nNature is the ultimate revolutionary. Its systems are decentralized, resilient, and inherently collective. To survive the climate crisis, we must learn to think like a forest. This means embracing interdependence and moving away from the extractive logic of industrial capitalism.\n\n![Radical Ecology](https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1200&auto=format&fit=crop)\n\nRadical ecology is about more than just conservation. It is about a fundamental shift in our relationship with the living world. It is about recognizing that we are not separate from nature, but a part of it.",
        tags: JSON.stringify(["ecology", "nature", "world", "climate"])
      },
      {
        id: "3",
        slug: "resistance-in-the-heart-of-the-empire",
        title: "Resistance in the Heart of the Empire",
        author: "Street Voice",
        categories: JSON.stringify(["Politics", "Revolutionary Thought"]),
        publishedAt: "FEB 26, 2026",
        image: "https://images.unsplash.com/photo-1516211697129-83d24df54f46?q=80&w=1200&auto=format&fit=crop",
        dek: "Protesters reclaim the streets against the rising tide of authoritarianism.",
        excerpt: "The streets belong to those who walk them with purpose...",
        content: "# Resistance\n\nEvery brick thrown is a word spoken in a language the powerful refuse to learn. In the heart of the empire, a new generation of activists is reclaiming the streets. They are not just protesting; they are building alternative structures of care and solidarity.\n\n![Resistance](https://images.unsplash.com/photo-1516211697129-83d24df54f46?q=80&w=1200&auto=format&fit=crop)\n\nThis is a struggle for the future. It is a struggle against the forces of surveillance and control. But it is also a struggle for joy, for community, and for the right to imagine a different world.",
        tags: JSON.stringify(["resistance", "politics", "protest", "solidarity"])
      },
      {
        id: "4",
        slug: "the-brazilian-soul-art-and-struggle",
        title: "The Brazilian Soul: Art and Struggle",
        author: "Ana Silva",
        categories: JSON.stringify(["Culture"]),
        publishedAt: "FEB 27, 2026",
        image: "https://images.unsplash.com/photo-1520156555810-664405323931?q=80&w=1200&auto=format&fit=crop",
        dek: "Artistic expressions of identity and struggle from the heart of South America.",
        excerpt: "In the favelas of Brazil, art is not a luxury; it is a weapon...",
        content: "# The Brazilian Soul\n\nBrazil is a land of profound contradictions and immense creative energy. From the vibrant street art of São Paulo to the traditional rhythms of the Northeast, art is a central part of the struggle for justice and identity.\n\n![Brazilian Soul](https://images.unsplash.com/photo-1520156555810-664405323931?q=80&w=1200&auto=format&fit=crop)\n\nThis article explores how Brazilian artists are using their work to challenge the status quo and imagine a more inclusive future. It is a testament to the power of culture to inspire and mobilize.",
        tags: JSON.stringify(["culture", "brazil", "art", "identity"])
      },
      {
        id: "5",
        slug: "economics-of-the-commons",
        title: "Economics of the Commons",
        author: "Elinor Ostrom (Legacy)",
        categories: JSON.stringify(["Economics", "Collective Intelligence"]),
        publishedAt: "FEB 28, 2026",
        image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=1200&auto=format&fit=crop",
        dek: "Beyond the market and the state: how communities manage shared resources.",
        excerpt: "The tragedy of the commons is a myth. Communities have been managing shared resources for centuries...",
        content: "# Economics of the Commons\n\nFor too long, we have been told that there are only two ways to manage resources: the market or the state. But there is a third way: the commons. This article revisits the work of Elinor Ostrom and explores how communities around the world are successfully managing shared resources without central control.\n\n![Commons](https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=1200&auto=format&fit=crop)\n\nFrom community-managed forests to open-source software, the commons offer a powerful alternative to the extractive logic of capitalism. It is an economics of care, cooperation, and sustainability.",
        tags: JSON.stringify(["economics", "commons", "sustainability", "cooperation"])
      }
    ];

    const insert = db.prepare(`
      INSERT INTO articles (id, slug, title, author, categories, publishedAt, image, dek, excerpt, content, tags, image_prompt)
      VALUES (@id, @slug, @title, @author, @categories, @publishedAt, @image, @dek, @excerpt, @content, @tags, @image_prompt)
    `);

    for (const art of seedArticles) {
      insert.run({ ...art, image_prompt: null });
    }
  }

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
